import { createContext, useContext, useState, ReactNode } from "react";
import { CartItem, DeliveryOption, PaymentMethod, OrderDetails } from "@shared/types";

interface CartContextType {
  cartItems: CartItem[];
  addToCart: (item: CartItem) => void;
  removeFromCart: (itemId: number) => void;
  updateQuantity: (itemId: number, quantity: number) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  toggleCartOpen: () => void;
  isCheckoutMode: boolean;
  setCheckoutMode: (mode: boolean) => void;
  deliveryOption: DeliveryOption;
  setDeliveryOption: (option: DeliveryOption) => void;
  paymentMethod: PaymentMethod;
  setPaymentMethod: (method: PaymentMethod) => void;
  orderDetails: Partial<OrderDetails>;
  updateOrderDetails: (details: Partial<OrderDetails>) => void;
  placeOrder: () => Promise<void>;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutMode, setIsCheckoutMode] = useState(false);
  const [deliveryOption, setDeliveryOption] = useState<DeliveryOption>("delivery");
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("cash");
  const [orderDetails, setOrderDetails] = useState<Partial<OrderDetails>>({
    deliveryOption: "delivery",
    paymentMethod: "cash",
    phone: "",
    address: "",
    notes: ""
  });

  const addToCart = (newItem: CartItem) => {
    setCartItems((prevItems) => {
      const existingItemIndex = prevItems.findIndex(
        (item) => item.id === newItem.id && 
          // For beverages, we need to check size as well
          (newItem.item.type !== "beverage" || 
           item.selectedSize === newItem.selectedSize)
      );

      if (existingItemIndex >= 0) {
        const updatedItems = [...prevItems];
        updatedItems[existingItemIndex].quantity += newItem.quantity;
        return updatedItems;
      } else {
        return [...prevItems, newItem];
      }
    });
  };

  const removeFromCart = (itemId: number) => {
    setCartItems((prevItems) =>
      prevItems.filter((item) => item.id !== itemId)
    );
  };

  const updateQuantity = (itemId: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(itemId);
      return;
    }

    setCartItems((prevItems) =>
      prevItems.map((item) =>
        item.id === itemId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCartItems([]);
  };

  const toggleCartOpen = () => {
    setIsCartOpen(!isCartOpen);
    if (isCheckoutMode && !isCartOpen) {
      setIsCheckoutMode(false);
    }
  };

  const setCheckoutMode = (mode: boolean) => {
    setIsCheckoutMode(mode);
  };

  const updateOrderDetails = (details: Partial<OrderDetails>) => {
    setOrderDetails(prev => ({ ...prev, ...details }));
    
    // Update delivery option and payment method if they're included in the details
    if (details.deliveryOption) {
      setDeliveryOption(details.deliveryOption);
    }
    if (details.paymentMethod) {
      setPaymentMethod(details.paymentMethod);
    }
  };

  const placeOrder = async () => {
    // In a real app, we would send the order to the server here
    // For now, we'll just clear the cart and close the modal
    
    console.log("Placing order with details:", {
      items: cartItems,
      ...orderDetails,
      deliveryOption,
      paymentMethod
    });
    
    clearCart();
    setIsCartOpen(false);
    setIsCheckoutMode(false);
    setOrderDetails({
      deliveryOption: "delivery",
      paymentMethod: "cash",
      phone: "",
      address: "",
      notes: ""
    });
    
    return Promise.resolve();
  };

  return (
    <CartContext.Provider
      value={{
        cartItems,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        isCartOpen,
        toggleCartOpen,
        isCheckoutMode,
        setCheckoutMode,
        deliveryOption,
        setDeliveryOption,
        paymentMethod,
        setPaymentMethod,
        orderDetails,
        updateOrderDetails,
        placeOrder
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}
