import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

// Translations
const resources = {
  uz: {
    translation: {
      nav: {
        home: 'Bosh sahifa',
        search: 'Qidirish',
        menu: 'Menu',
        favorites: 'Sevimlilar',
        profile: 'Profil'
      },
      navigation: {
        home: 'Bosh sahifa',
        menu: 'Menu',
        promotions: 'Aksiyalar',
        about: 'Biz haqimizda',
        contact: 'Aloqa'
      },
      search: {
        placeholder: 'Ovqat qidirish...',
        button: 'Qidirish'
      },
      trendingProducts: {
        title: 'Ommabop Mahsulotlar',
        viewAll: 'Hammasini ko\'rish'
      },
      addToCart: 'Qo\'shish',
      hero: {
        title: 'Mazali va tez yetkazib berish',
        description: 'Singo Fast Food\'da siz sevgan barcha ovqatlarni buyurtma qiling va tez yetkazib berishdan bahramand bo\'ling!',
        orderNow: 'Hozir buyurtma bering',
        viewMenu: 'Menuni ko\'ring'
      },
      bestsellers: {
        title: 'Eng ko\'p sotilganlar',
        viewAll: 'Hammasini ko\'rish',
        bestseller: 'Bestseller',
        discount: 'Chegirma'
      },
      menu: {
        title: 'Bizning Menu',
        all: 'Hammasi'
      },
      promo: {
        downloadApp: 'Singo ilovasini yuklab oling!',
        appDescription: 'Bizning ilovani yuklab oling va birinchi buyurtmangizga',
        discount: '25% chegirma'
      },
      about: {
        aboutTitle: 'Biz haqimizda',
        aboutHeading: 'Singo Fast Food - Sizning sevimli fastfudingiz',
        description1: 'Singo Fast Food 2015 yildan beri O\'zbekistonda faoliyat yuritib kelmoqda. Bizning maqsadimiz - mijozlarimizga eng yuqori sifatli va mazali taomlarni tez va qulay tarzda yetkazib berishdir.',
        description2: 'Biz faqat eng sifatli mahsulotlardan foydalanamiz va barcha taomlarimiz malakali oshpazlarimiz tomonidan tayyorlanadi. Bizning xizmatimiz tez, qulay va ishonchli.',
        fastDelivery: 'Tez yetkazib berish',
        fastDeliveryDescription: '30 daqiqa ichida',
        highQuality: 'Yuqori sifat',
        highQualityDescription: 'Eng yangi masalliqlar',
        easyPayment: 'Qulay to\'lov',
        easyPaymentDescription: 'Naqd va karta orqali',
        customers: '1000+ mijozlar',
        customersDescription: 'Har kuni',
        moreDetails: 'Batafsil ma\'lumot',
        experience: '8 yillik tajriba',
        experienceDescription: '2015 yildan beri'
      },
      footer: {
        companyInfo: 'Mazali taomlarni tez va qulay yetkazib berish xizmati. 2015 yildan beri Toshkent aholisiga xizmat ko\'rsatib kelmoqda.',
        menu: 'Menyu',
        company: 'Kompaniya',
        contact: 'Aloqa',
        workHours: 'Ish vaqtlari',
        workHoursValue: 'Har kuni: 9:00 - 22:00',
        rights: 'Barcha huquqlar himoyalangan.',
        privacy: 'Maxfiylik siyosati',
        terms: 'Foydalanish shartlari'
      },
      cart: {
        yourCart: 'Sizning savatingiz',
        emptyCart: 'Savatingiz bo\'sh',
        totalAmount: 'Umumiy summa',
        delivery: 'Yetkazib berish',
        total: 'Jami',
        placeOrder: 'Buyurtma berish',
        deliveryOptions: 'Yetkazib berish usuli',
        deliveryMethod: 'Yetkazib berish',
        pickupMethod: 'Olib ketish',
        paymentMethods: 'To\'lov usuli',
        cashPayment: 'Naqd pul',
        cardToCardPayment: 'Karta orqali o\'tkazma',
        clickPayment: 'Click',
        paymePayment: 'Payme',
        phoneNumber: 'Telefon raqami',
        address: 'Manzil',
        notes: 'Qo\'shimcha ma\'lumot',
        enterPhone: 'Telefon raqamingizni kiriting',
        enterAddress: 'Yetkazib berish manzilini kiriting',
        enterNotes: 'Qo\'shimcha ma\'lumot kiriting',
        checkout: 'Buyurtmani tasdiqlash',
        continueShopping: 'Xaridni davom ettirish'
      }
    }
  },
  ru: {
    translation: {
      nav: {
        home: 'Главная',
        search: 'Поиск',
        menu: 'Меню',
        favorites: 'Избранное',
        profile: 'Профиль'
      },
      navigation: {
        home: 'Главная',
        menu: 'Меню',
        promotions: 'Акции',
        about: 'О нас',
        contact: 'Контакты'
      },
      search: {
        placeholder: 'Поиск еды...',
        button: 'Поиск'
      },
      trendingProducts: {
        title: 'Популярные Блюда',
        viewAll: 'Смотреть все'
      },
      addToCart: 'Добавить',
      hero: {
        title: 'Вкусная и быстрая доставка',
        description: 'Заказывайте все ваши любимые блюда в Singo Fast Food и наслаждайтесь быстрой доставкой!',
        orderNow: 'Заказать сейчас',
        viewMenu: 'Смотреть меню'
      },
      bestsellers: {
        title: 'Самые популярные',
        viewAll: 'Смотреть все',
        bestseller: 'Хит продаж',
        discount: 'Скидка'
      },
      menu: {
        title: 'Наше Меню',
        all: 'Все'
      },
      promo: {
        downloadApp: 'Скачайте приложение Singo!',
        appDescription: 'Скачайте наше приложение и получите',
        discount: 'скидку 25%'
      },
      about: {
        aboutTitle: 'О нас',
        aboutHeading: 'Singo Fast Food - Ваш любимый фастфуд',
        description1: 'Singo Fast Food работает в Узбекистане с 2015 года. Наша цель - предоставить нашим клиентам высококачественную и вкусную еду быстро и удобно.',
        description2: 'Мы используем только качественные продукты, и все наши блюда готовятся квалифицированными поварами. Наш сервис быстрый, удобный и надежный.',
        fastDelivery: 'Быстрая доставка',
        fastDeliveryDescription: 'В течение 30 минут',
        highQuality: 'Высокое качество',
        highQualityDescription: 'Свежие ингредиенты',
        easyPayment: 'Удобная оплата',
        easyPaymentDescription: 'Наличными и картой',
        customers: '1000+ клиентов',
        customersDescription: 'Каждый день',
        moreDetails: 'Подробнее',
        experience: '8 лет опыта',
        experienceDescription: 'С 2015 года'
      },
      footer: {
        companyInfo: 'Служба быстрой и удобной доставки вкусной еды. Обслуживаем жителей Ташкента с 2015 года.',
        menu: 'Меню',
        company: 'Компания',
        contact: 'Контакты',
        workHours: 'Часы работы',
        workHoursValue: 'Ежедневно: 9:00 - 22:00',
        rights: 'Все права защищены.',
        privacy: 'Политика конфиденциальности',
        terms: 'Условия использования'
      },
      cart: {
        yourCart: 'Ваша корзина',
        emptyCart: 'Ваша корзина пуста',
        totalAmount: 'Общая сумма',
        delivery: 'Доставка',
        total: 'Итого',
        placeOrder: 'Оформить заказ',
        deliveryOptions: 'Способ доставки',
        deliveryMethod: 'Доставка',
        pickupMethod: 'Самовывоз',
        paymentMethods: 'Способ оплаты',
        cashPayment: 'Наличные',
        cardToCardPayment: 'Перевод на карту',
        clickPayment: 'Click',
        paymePayment: 'Payme',
        phoneNumber: 'Номер телефона',
        address: 'Адрес',
        notes: 'Примечания',
        enterPhone: 'Введите ваш номер телефона',
        enterAddress: 'Введите адрес доставки',
        enterNotes: 'Введите примечания к заказу',
        checkout: 'Подтвердить заказ',
        continueShopping: 'Продолжить покупки'
      }
    }
  },
  en: {
    translation: {
      nav: {
        home: 'Home',
        search: 'Search',
        menu: 'Menu',
        favorites: 'Favorites',
        profile: 'Profile'
      },
      navigation: {
        home: 'Home',
        menu: 'Menu',
        promotions: 'Promotions',
        about: 'About Us',
        contact: 'Contact'
      },
      search: {
        placeholder: 'Search for food...',
        button: 'Search'
      },
      trendingProducts: {
        title: 'Trending Products',
        viewAll: 'View All'
      },
      addToCart: 'Add',
      hero: {
        title: 'Delicious and Fast Delivery',
        description: 'Order all your favorite foods at Singo Fast Food and enjoy our quick delivery service!',
        orderNow: 'Order Now',
        viewMenu: 'View Menu'
      },
      bestsellers: {
        title: 'Bestsellers',
        viewAll: 'View All',
        bestseller: 'Bestseller',
        discount: 'Discount'
      },
      menu: {
        title: 'Our Menu',
        all: 'All'
      },
      promo: {
        downloadApp: 'Download the Singo app!',
        appDescription: 'Download our app and get',
        discount: '25% off'
      },
      about: {
        aboutTitle: 'About Us',
        aboutHeading: 'Singo Fast Food - Your Favorite Fast Food',
        description1: 'Singo Fast Food has been operating in Uzbekistan since 2015. Our goal is to provide our customers with high-quality and delicious food quickly and conveniently.',
        description2: 'We use only quality products, and all our dishes are prepared by qualified chefs. Our service is fast, convenient, and reliable.',
        fastDelivery: 'Fast Delivery',
        fastDeliveryDescription: 'Within 30 minutes',
        highQuality: 'High Quality',
        highQualityDescription: 'Fresh ingredients',
        easyPayment: 'Easy Payment',
        easyPaymentDescription: 'Cash and card',
        customers: '1000+ customers',
        customersDescription: 'Every day',
        moreDetails: 'More Details',
        experience: '8 years of experience',
        experienceDescription: 'Since 2015'
      },
      footer: {
        companyInfo: 'Fast and convenient delivery service for delicious food. Serving Tashkent residents since 2015.',
        menu: 'Menu',
        company: 'Company',
        contact: 'Contact',
        workHours: 'Working Hours',
        workHoursValue: 'Daily: 9:00 - 22:00',
        rights: 'All rights reserved.',
        privacy: 'Privacy Policy',
        terms: 'Terms of Use'
      },
      cart: {
        yourCart: 'Your Cart',
        emptyCart: 'Your cart is empty',
        totalAmount: 'Total amount',
        delivery: 'Delivery',
        total: 'Total',
        placeOrder: 'Place Order',
        deliveryOptions: 'Delivery Options',
        deliveryMethod: 'Delivery',
        pickupMethod: 'Pickup',
        paymentMethods: 'Payment Methods',
        cashPayment: 'Cash Payment',
        cardToCardPayment: 'Card-to-Card Transfer',
        clickPayment: 'Click',
        paymePayment: 'Payme',
        phoneNumber: 'Phone Number',
        address: 'Address',
        notes: 'Notes',
        enterPhone: 'Enter your phone number',
        enterAddress: 'Enter delivery address',
        enterNotes: 'Enter order notes',
        checkout: 'Checkout',
        continueShopping: 'Continue Shopping'
      }
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: 'uz', // default language
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
