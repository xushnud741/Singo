import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import AdminLayout from '@/components/admin/AdminLayout';
import { getQueryFn, apiRequest } from '@/lib/queryClient';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from "@/components/ui/badge";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Search, Eye, FilterX } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { formatPrice } from '@/lib/utils';

interface Order {
  id: number;
  userId: number | null;
  customerName: string | null;
  customerPhone: string;
  customerAddress: string | null;
  orderItems: any;
  totalAmount: number;
  status: 'pending' | 'processing' | 'out_for_delivery' | 'delivered' | 'cancelled';
  paymentMethod: string;
  deliveryOption: string;
  createdAt: string;
  updatedAt: string;
}

export default function AdminOrders() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [viewOrderId, setViewOrderId] = useState<number | null>(null);
  
  const { data: orders = [], isLoading: isOrdersLoading } = useQuery({
    queryKey: ['/api/orders'],
    queryFn: getQueryFn({ on401: 'throw' })
  });

  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) => 
      apiRequest('PATCH', `/api/orders/${id}/status`, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/orders'] });
      toast({
        title: 'Order Status Updated',
        description: 'The order status has been updated successfully',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Failed to update order status',
        variant: 'destructive',
      });
    }
  });

  const filteredOrders = orders.filter((order: Order) => {
    const matchesSearch = 
      order.customerPhone.includes(searchTerm) || 
      (order.customerName && order.customerName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      String(order.id).includes(searchTerm);
    
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const getCurrentOrder = () => {
    if (!viewOrderId) return null;
    return orders.find((order: Order) => order.id === viewOrderId);
  };

  const currentOrder = getCurrentOrder();

  const statusColorMap = {
    pending: "bg-yellow-100 text-yellow-800 hover:bg-yellow-200 dark:bg-yellow-700/20 dark:text-yellow-500",
    processing: "bg-blue-100 text-blue-800 hover:bg-blue-200 dark:bg-blue-700/20 dark:text-blue-500",
    out_for_delivery: "bg-purple-100 text-purple-800 hover:bg-purple-200 dark:bg-purple-700/20 dark:text-purple-500",
    delivered: "bg-green-100 text-green-800 hover:bg-green-200 dark:bg-green-700/20 dark:text-green-500",
    cancelled: "bg-red-100 text-red-800 hover:bg-red-200 dark:bg-red-700/20 dark:text-red-500",
  };

  const statusDisplayNames = {
    pending: "Pending",
    processing: "Processing",
    out_for_delivery: "Out for Delivery",
    delivered: "Delivered",
    cancelled: "Cancelled",
  };

  const handleUpdateStatus = (id: number, status: string) => {
    updateStatusMutation.mutate({ id, status });
  };

  return (
    <AdminLayout title="Orders">
      <div className="flex flex-col md:flex-row gap-4 justify-between mb-4">
        <div className="flex items-center gap-2 w-full md:w-1/2">
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by ID, phone or name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select
            value={statusFilter}
            onValueChange={setStatusFilter}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="All Statuses" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              {Object.keys(statusDisplayNames).map((status) => (
                <SelectItem key={status} value={status}>
                  {statusDisplayNames[status]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {(searchTerm || statusFilter !== 'all') && (
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => {
                setSearchTerm('');
                setStatusFilter('all');
              }}
              title="Clear filters"
            >
              <FilterX className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>

      <div className="rounded-md border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Items</TableHead>
              <TableHead>Total</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Date</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredOrders.length > 0 ? (
              filteredOrders.map((order: Order) => (
                <TableRow key={order.id}>
                  <TableCell className="font-medium">{order.id}</TableCell>
                  <TableCell>
                    <div>{order.customerName || 'N/A'}</div>
                    <div className="text-sm text-muted-foreground">{order.customerPhone}</div>
                  </TableCell>
                  <TableCell>
                    {Array.isArray(order.orderItems) ? (
                      <div>{order.orderItems.length} items</div>
                    ) : (
                      <div>Items unavailable</div>
                    )}
                  </TableCell>
                  <TableCell>UZS {order.totalAmount.toLocaleString()}</TableCell>
                  <TableCell>
                    <Badge className={statusColorMap[order.status]}>
                      {statusDisplayNames[order.status]}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {new Date(order.createdAt).toLocaleDateString()}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end items-center gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setViewOrderId(order.id)}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-4">
                  {isOrdersLoading ? (
                    <div className="flex justify-center items-center">
                      <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full"></div>
                      <span className="ml-2">Loading orders...</span>
                    </div>
                  ) : (
                    <div>No orders found. Adjust your filters or check back later.</div>
                  )}
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {/* Order Details Dialog */}
      <Dialog open={viewOrderId !== null} onOpenChange={(open) => !open && setViewOrderId(null)}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          {currentOrder ? (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center justify-between">
                  <span>Order #{currentOrder.id}</span>
                  <Badge className={statusColorMap[currentOrder.status]}>
                    {statusDisplayNames[currentOrder.status]}
                  </Badge>
                </DialogTitle>
                <DialogDescription>
                  Placed on {new Date(currentOrder.createdAt).toLocaleString()}
                </DialogDescription>
              </DialogHeader>

              <Tabs defaultValue="details">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="details">Details</TabsTrigger>
                  <TabsTrigger value="customer">Customer</TabsTrigger>
                  <TabsTrigger value="status">Status</TabsTrigger>
                </TabsList>

                <TabsContent value="details" className="py-4 space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Order Items</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {Array.isArray(currentOrder.orderItems) ? (
                        <div className="space-y-3">
                          {currentOrder.orderItems.map((item, index) => (
                            <div key={index} className="flex justify-between items-center py-2 border-b">
                              <div className="flex items-center gap-3">
                                {item.item.image && (
                                  <img
                                    src={item.item.image}
                                    alt={item.item.title}
                                    className="w-12 h-12 object-cover rounded"
                                  />
                                )}
                                <div>
                                  <div className="font-medium">{item.item.title}</div>
                                  {item.selectedSize && (
                                    <div className="text-sm text-muted-foreground">
                                      Size: {item.selectedSize}
                                    </div>
                                  )}
                                  <div className="text-sm">Qty: {item.quantity}</div>
                                </div>
                              </div>
                              <div className="text-right">
                                <div>
                                  UZS {((item.item.price || 0) * (item.quantity || 1)).toLocaleString()}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div>No items available</div>
                      )}
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Order Summary</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span>Subtotal</span>
                          <span>UZS {currentOrder.totalAmount.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Delivery Fee</span>
                          <span>UZS 0</span>
                        </div>
                        <div className="flex justify-between pt-2 border-t font-medium">
                          <span>Total</span>
                          <span>UZS {currentOrder.totalAmount.toLocaleString()}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Payment Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span>Payment Method</span>
                          <span className="capitalize">{currentOrder.paymentMethod}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Delivery Option</span>
                          <span className="capitalize">{currentOrder.deliveryOption}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="customer" className="py-4 space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Customer Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="font-medium">Name</span>
                          <span>{currentOrder.customerName || 'N/A'}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="font-medium">Phone</span>
                          <span>{currentOrder.customerPhone}</span>
                        </div>
                        {currentOrder.deliveryOption === 'delivery' && (
                          <div className="flex justify-between">
                            <span className="font-medium">Address</span>
                            <span>{currentOrder.customerAddress || 'N/A'}</span>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="status" className="py-4 space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Update Order Status</CardTitle>
                      <CardDescription>
                        Change the current status of this order
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                          {Object.keys(statusDisplayNames).map((status) => (
                            <Button
                              key={status}
                              variant={currentOrder.status === status ? "default" : "outline"}
                              className={`justify-start ${currentOrder.status === status ? '' : statusColorMap[status]}`}
                              disabled={updateStatusMutation.isPending || currentOrder.status === status}
                              onClick={() => handleUpdateStatus(currentOrder.id, status)}
                            >
                              {statusDisplayNames[status]}
                            </Button>
                          ))}
                        </div>
                        
                        <div className="text-sm text-muted-foreground">
                          Current Status: <span className="font-medium">{statusDisplayNames[currentOrder.status]}</span>
                          <br />
                          Last Updated: <span className="font-medium">{new Date(currentOrder.updatedAt).toLocaleString()}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </>
          ) : (
            <div className="flex justify-center items-center p-8">
              <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full"></div>
              <span className="ml-2">Loading order details...</span>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}