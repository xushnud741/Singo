import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import AdminLayout from '@/components/admin/AdminLayout';
import { getQueryFn, apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Edit, Trash2, Plus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Category {
  id: number;
  nameUz: string;
  nameRu: string;
  nameEn: string;
  slug: string;
}

export default function AdminCategories() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [categoryData, setCategoryData] = useState({
    nameUz: '',
    nameRu: '',
    nameEn: '',
    slug: ''
  });

  const { data: categories = [] } = useQuery({
    queryKey: ['/api/categories'],
    queryFn: getQueryFn({ on401: 'throw' })
  });

  const createMutation = useMutation({
    mutationFn: (newCategory) => 
      apiRequest('POST', '/api/admin/categories', newCategory),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
      setIsAddModalOpen(false);
      resetForm();
      toast({
        title: 'Category Added',
        description: 'The category has been added successfully',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Failed to add category',
        variant: 'destructive',
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: (updatedCategory) => 
      apiRequest('PUT', `/api/admin/categories/${selectedCategory?.id}`, updatedCategory),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
      setIsEditModalOpen(false);
      resetForm();
      toast({
        title: 'Category Updated',
        description: 'The category has been updated successfully',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Failed to update category',
        variant: 'destructive',
      });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => 
      apiRequest('DELETE', `/api/admin/categories/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
      toast({
        title: 'Category Deleted',
        description: 'The category has been deleted successfully',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Failed to delete category',
        variant: 'destructive',
      });
    }
  });

  const resetForm = () => {
    setCategoryData({
      nameUz: '',
      nameRu: '',
      nameEn: '',
      slug: ''
    });
    setSelectedCategory(null);
  };

  const handleEditClick = (category: Category) => {
    setSelectedCategory(category);
    setCategoryData({
      nameUz: category.nameUz,
      nameRu: category.nameRu,
      nameEn: category.nameEn,
      slug: category.slug
    });
    setIsEditModalOpen(true);
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate(categoryData);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateMutation.mutate(categoryData);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCategoryData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleAutoGenerateSlug = () => {
    // Generate slug from English name
    if (categoryData.nameEn) {
      const slug = categoryData.nameEn
        .toLowerCase()
        .replace(/[^a-z0-9\s-]/g, '')  // Remove special chars
        .replace(/\s+/g, '-')           // Replace spaces with -
        .replace(/-+/g, '-');           // Replace multiple - with single -
      
      setCategoryData(prev => ({
        ...prev,
        slug
      }));
    }
  };

  const CategoryForm = ({ onSubmit, buttonText }) => (
    <form onSubmit={onSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="nameUz">Name (Uzbek)</Label>
          <Input
            id="nameUz"
            name="nameUz"
            value={categoryData.nameUz}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="nameRu">Name (Russian)</Label>
          <Input
            id="nameRu"
            name="nameRu"
            value={categoryData.nameRu}
            onChange={handleInputChange}
            required
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="nameEn">Name (English)</Label>
        <Input
          id="nameEn"
          name="nameEn"
          value={categoryData.nameEn}
          onChange={handleInputChange}
          required
        />
      </div>

      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <Label htmlFor="slug">Slug</Label>
          <Button 
            type="button" 
            variant="outline" 
            size="sm"
            onClick={handleAutoGenerateSlug}
          >
            Auto-generate
          </Button>
        </div>
        <Input
          id="slug"
          name="slug"
          value={categoryData.slug}
          onChange={handleInputChange}
          required
        />
      </div>

      <DialogFooter>
        <Button 
          type="submit" 
          disabled={createMutation.isPending || updateMutation.isPending}
        >
          {createMutation.isPending || updateMutation.isPending ? 'Saving...' : buttonText}
        </Button>
      </DialogFooter>
    </form>
  );

  return (
    <AdminLayout title="Categories">
      <div className="flex justify-end mb-4">
        <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-1">
              <Plus className="h-4 w-4" />
              Add Category
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Category</DialogTitle>
              <DialogDescription>
                Create a new category for menu items
              </DialogDescription>
            </DialogHeader>
            <CategoryForm onSubmit={handleAddSubmit} buttonText="Add Category" />
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Name (Uzbek)</TableHead>
              <TableHead>Name (Russian)</TableHead>
              <TableHead>Name (English)</TableHead>
              <TableHead>Slug</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {categories.length > 0 ? (
              categories.map((category: Category) => (
                <TableRow key={category.id}>
                  <TableCell>{category.id}</TableCell>
                  <TableCell>{category.nameUz}</TableCell>
                  <TableCell>{category.nameRu}</TableCell>
                  <TableCell>{category.nameEn}</TableCell>
                  <TableCell>{category.slug}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end items-center gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEditClick(category)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Category</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete this category? This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => deleteMutation.mutate(category.id)}
                              className="bg-red-500 hover:bg-red-600"
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-4">
                  No categories found. Create your first category.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {/* Edit Dialog */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Category</DialogTitle>
            <DialogDescription>
              Update the details of this category
            </DialogDescription>
          </DialogHeader>
          <CategoryForm onSubmit={handleEditSubmit} buttonText="Update Category" />
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}