import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import AdminLayout from '@/components/admin/AdminLayout';
import { getQueryFn, apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Edit, Trash2, Plus, Star, Search, Utensils, Coffee } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface MenuItem {
  id: number;
  categoryId: number;
  titleUz: string;
  titleRu: string;
  titleEn: string;
  descriptionUz: string;
  descriptionRu: string;
  descriptionEn: string;
  price: number;
  image: string;
  isBestseller: boolean;
  discountPercentage: number;
  rating: number;
  type: 'food' | 'beverage';
  beverageSizes?: string;
}

interface Category {
  id: number;
  nameUz: string;
  nameRu: string;
  nameEn: string;
  slug: string;
}

interface BeverageSizes {
  small?: { volume: string; price: number };
  medium?: { volume: string; price: number };
  large?: { volume: string; price: number };
}

export default function AdminMenuItems() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedMenuItem, setSelectedMenuItem] = useState<MenuItem | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [menuItemData, setMenuItemData] = useState({
    categoryId: 0,
    titleUz: '',
    titleRu: '',
    titleEn: '',
    descriptionUz: '',
    descriptionRu: '',
    descriptionEn: '',
    price: 0,
    image: '',
    isBestseller: false,
    discountPercentage: 0,
    rating: 5.0,
    type: 'food' as 'food' | 'beverage',
    beverageSizes: {
      small: { volume: '0.3L', price: 0 },
      medium: { volume: '0.5L', price: 0 },
      large: { volume: '0.7L', price: 0 }
    }
  });

  const { data: menuItems = [] } = useQuery({
    queryKey: ['/api/menu'],
    queryFn: getQueryFn({ on401: 'throw' })
  });

  const { data: categories = [] } = useQuery({
    queryKey: ['/api/categories'],
    queryFn: getQueryFn({ on401: 'throw' })
  });

  const createMutation = useMutation({
    mutationFn: (newMenuItem) => {
      // For beverage type, convert beverageSizes to JSON string
      if (newMenuItem.type === 'beverage') {
        return apiRequest('POST', '/api/admin/menu', {
          ...newMenuItem,
          beverageSizes: JSON.stringify(newMenuItem.beverageSizes)
        });
      }
      // For food type, don't include beverageSizes
      return apiRequest('POST', '/api/admin/menu', {
        ...newMenuItem,
        beverageSizes: undefined
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/menu'] });
      setIsAddModalOpen(false);
      resetForm();
      toast({
        title: 'Menu Item Added',
        description: 'The menu item has been added successfully',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Failed to add menu item',
        variant: 'destructive',
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: (updatedMenuItem) => {
      // For beverage type, convert beverageSizes to JSON string
      if (updatedMenuItem.type === 'beverage') {
        return apiRequest('PUT', `/api/admin/menu/${selectedMenuItem?.id}`, {
          ...updatedMenuItem,
          beverageSizes: JSON.stringify(updatedMenuItem.beverageSizes)
        });
      }
      // For food type, don't include beverageSizes
      return apiRequest('PUT', `/api/admin/menu/${selectedMenuItem?.id}`, {
        ...updatedMenuItem,
        beverageSizes: undefined
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/menu'] });
      setIsEditModalOpen(false);
      resetForm();
      toast({
        title: 'Menu Item Updated',
        description: 'The menu item has been updated successfully',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Failed to update menu item',
        variant: 'destructive',
      });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => 
      apiRequest('DELETE', `/api/admin/menu/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/menu'] });
      toast({
        title: 'Menu Item Deleted',
        description: 'The menu item has been deleted successfully',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Failed to delete menu item',
        variant: 'destructive',
      });
    }
  });

  const resetForm = () => {
    setMenuItemData({
      categoryId: 0,
      titleUz: '',
      titleRu: '',
      titleEn: '',
      descriptionUz: '',
      descriptionRu: '',
      descriptionEn: '',
      price: 0,
      image: '',
      isBestseller: false,
      discountPercentage: 0,
      rating: 5.0,
      type: 'food',
      beverageSizes: {
        small: { volume: '0.3L', price: 0 },
        medium: { volume: '0.5L', price: 0 },
        large: { volume: '0.7L', price: 0 }
      }
    });
    setSelectedMenuItem(null);
  };

  const handleEditClick = (menuItem: MenuItem) => {
    setSelectedMenuItem(menuItem);
    const beverageSizes = menuItem.beverageSizes 
      ? JSON.parse(menuItem.beverageSizes) 
      : {
          small: { volume: '0.3L', price: 0 },
          medium: { volume: '0.5L', price: 0 },
          large: { volume: '0.7L', price: 0 }
        };
    
    setMenuItemData({
      categoryId: menuItem.categoryId,
      titleUz: menuItem.titleUz,
      titleRu: menuItem.titleRu,
      titleEn: menuItem.titleEn,
      descriptionUz: menuItem.descriptionUz,
      descriptionRu: menuItem.descriptionRu,
      descriptionEn: menuItem.descriptionEn,
      price: menuItem.price,
      image: menuItem.image,
      isBestseller: menuItem.isBestseller,
      discountPercentage: menuItem.discountPercentage,
      rating: menuItem.rating,
      type: menuItem.type,
      beverageSizes
    });
    setIsEditModalOpen(true);
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate(menuItemData);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateMutation.mutate(menuItemData);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    
    // Handle numeric values
    if (name === 'price' || name === 'discountPercentage' || name === 'rating') {
      setMenuItemData(prev => ({
        ...prev,
        [name]: parseFloat(value) || 0
      }));
    } else {
      setMenuItemData(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };

  const handleBeverageSizeChange = (size: 'small' | 'medium' | 'large', field: 'volume' | 'price', value: string) => {
    setMenuItemData(prev => ({
      ...prev,
      beverageSizes: {
        ...prev.beverageSizes,
        [size]: {
          ...prev.beverageSizes[size],
          [field]: field === 'price' ? (parseFloat(value) || 0) : value
        }
      }
    }));
  };

  const handleCategoryChange = (value: string) => {
    setMenuItemData(prev => ({
      ...prev,
      categoryId: parseInt(value)
    }));
  };

  const handleTypeChange = (value: 'food' | 'beverage') => {
    setMenuItemData(prev => ({
      ...prev,
      type: value
    }));
  };

  const handleCheckboxChange = (checked: boolean) => {
    setMenuItemData(prev => ({
      ...prev,
      isBestseller: checked
    }));
  };

  const filteredMenuItems = menuItems.filter((item: MenuItem) => {
    const matchesSearch = item.titleEn.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.titleUz.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.titleRu.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = selectedCategory === 'all' || 
                           item.categoryId === parseInt(selectedCategory);
    
    return matchesSearch && matchesCategory;
  });

  const getCategoryName = (categoryId: number) => {
    const category = categories.find((cat: Category) => cat.id === categoryId);
    return category ? category.nameEn : '';
  };

  const MenuItemForm = ({ onSubmit, buttonText }) => (
    <form onSubmit={onSubmit} className="space-y-4">
      <Tabs defaultValue="general">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="translations">Translations</TabsTrigger>
          <TabsTrigger value="pricing">Pricing</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="py-4 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="categoryId">Category</Label>
            <Select
              value={menuItemData.categoryId.toString()}
              onValueChange={handleCategoryChange}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category: Category) => (
                  <SelectItem key={category.id} value={category.id.toString()}>
                    {category.nameEn}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="type">Item Type</Label>
            <div className="flex gap-4">
              <div className="flex items-center space-x-2">
                <Button
                  type="button"
                  variant={menuItemData.type === 'food' ? 'default' : 'outline'}
                  onClick={() => handleTypeChange('food')}
                  className="flex items-center gap-2"
                >
                  <Utensils className="h-4 w-4" />
                  Food
                </Button>
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  type="button"
                  variant={menuItemData.type === 'beverage' ? 'default' : 'outline'}
                  onClick={() => handleTypeChange('beverage')}
                  className="flex items-center gap-2"
                >
                  <Coffee className="h-4 w-4" />
                  Beverage
                </Button>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="image">Image URL</Label>
            <Input
              id="image"
              name="image"
              value={menuItemData.image}
              onChange={handleInputChange}
              placeholder="https://example.com/image.jpg"
              required
            />
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="isBestseller"
              checked={menuItemData.isBestseller}
              onCheckedChange={handleCheckboxChange}
            />
            <Label htmlFor="isBestseller" className="flex items-center gap-1">
              <Star className="h-4 w-4 text-yellow-500" />
              Mark as bestseller
            </Label>
          </div>
        </TabsContent>

        <TabsContent value="translations" className="py-4 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="titleUz">Title (Uzbek)</Label>
            <Input
              id="titleUz"
              name="titleUz"
              value={menuItemData.titleUz}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="titleRu">Title (Russian)</Label>
            <Input
              id="titleRu"
              name="titleRu"
              value={menuItemData.titleRu}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="titleEn">Title (English)</Label>
            <Input
              id="titleEn"
              name="titleEn"
              value={menuItemData.titleEn}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="descriptionUz">Description (Uzbek)</Label>
            <Textarea
              id="descriptionUz"
              name="descriptionUz"
              value={menuItemData.descriptionUz}
              onChange={handleInputChange}
              rows={2}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="descriptionRu">Description (Russian)</Label>
            <Textarea
              id="descriptionRu"
              name="descriptionRu"
              value={menuItemData.descriptionRu}
              onChange={handleInputChange}
              rows={2}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="descriptionEn">Description (English)</Label>
            <Textarea
              id="descriptionEn"
              name="descriptionEn"
              value={menuItemData.descriptionEn}
              onChange={handleInputChange}
              rows={2}
              required
            />
          </div>
        </TabsContent>

        <TabsContent value="pricing" className="py-4 space-y-4">
          {menuItemData.type === 'food' ? (
            <div className="space-y-2">
              <Label htmlFor="price">Price (UZS)</Label>
              <Input
                id="price"
                name="price"
                type="number"
                value={menuItemData.price}
                onChange={handleInputChange}
                min="0"
                required
              />
            </div>
          ) : (
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Beverage Sizes</h3>
              
              <Card>
                <CardContent className="pt-4 space-y-2">
                  <div className="grid grid-cols-3 gap-2">
                    <Label>Small</Label>
                    <Input
                      placeholder="Volume (0.3L)"
                      value={menuItemData.beverageSizes.small.volume}
                      onChange={(e) => handleBeverageSizeChange('small', 'volume', e.target.value)}
                    />
                    <Input
                      type="number"
                      placeholder="Price"
                      value={menuItemData.beverageSizes.small.price}
                      onChange={(e) => handleBeverageSizeChange('small', 'price', e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-4 space-y-2">
                  <div className="grid grid-cols-3 gap-2">
                    <Label>Medium</Label>
                    <Input
                      placeholder="Volume (0.5L)"
                      value={menuItemData.beverageSizes.medium.volume}
                      onChange={(e) => handleBeverageSizeChange('medium', 'volume', e.target.value)}
                    />
                    <Input
                      type="number"
                      placeholder="Price"
                      value={menuItemData.beverageSizes.medium.price}
                      onChange={(e) => handleBeverageSizeChange('medium', 'price', e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-4 space-y-2">
                  <div className="grid grid-cols-3 gap-2">
                    <Label>Large</Label>
                    <Input
                      placeholder="Volume (0.7L)"
                      value={menuItemData.beverageSizes.large.volume}
                      onChange={(e) => handleBeverageSizeChange('large', 'volume', e.target.value)}
                    />
                    <Input
                      type="number"
                      placeholder="Price"
                      value={menuItemData.beverageSizes.large.price}
                      onChange={(e) => handleBeverageSizeChange('large', 'price', e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>
              
              <div className="text-sm text-muted-foreground">
                The base price is used for the small size. For beverages, customers can select different sizes.
              </div>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="discountPercentage">Discount Percentage</Label>
            <Input
              id="discountPercentage"
              name="discountPercentage"
              type="number"
              value={menuItemData.discountPercentage}
              onChange={handleInputChange}
              min="0"
              max="100"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="rating">Rating (1-5)</Label>
            <Input
              id="rating"
              name="rating"
              type="number"
              value={menuItemData.rating}
              onChange={handleInputChange}
              min="1"
              max="5"
              step="0.1"
            />
          </div>
        </TabsContent>
      </Tabs>

      <DialogFooter>
        <Button 
          type="submit" 
          disabled={createMutation.isPending || updateMutation.isPending}
        >
          {createMutation.isPending || updateMutation.isPending ? 'Saving...' : buttonText}
        </Button>
      </DialogFooter>
    </form>
  );

  return (
    <AdminLayout title="Menu Items">
      <div className="flex flex-col md:flex-row gap-4 justify-between mb-4">
        <div className="flex items-center gap-2 w-full md:w-1/2">
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search menu items..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select
            value={selectedCategory}
            onValueChange={setSelectedCategory}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map((category: Category) => (
                <SelectItem key={category.id} value={category.id.toString()}>
                  {category.nameEn}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-1">
              <Plus className="h-4 w-4" />
              Add Menu Item
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Add New Menu Item</DialogTitle>
              <DialogDescription>
                Create a new menu item for your customers
              </DialogDescription>
            </DialogHeader>
            <MenuItemForm onSubmit={handleAddSubmit} buttonText="Add Menu Item" />
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-md border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Image</TableHead>
              <TableHead>Title</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Price</TableHead>
              <TableHead className="text-center">Bestseller</TableHead>
              <TableHead className="text-center">Discount</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredMenuItems.length > 0 ? (
              filteredMenuItems.map((item: MenuItem) => (
                <TableRow key={item.id}>
                  <TableCell>
                    <img 
                      src={item.image} 
                      alt={item.titleEn} 
                      className="w-12 h-12 object-cover rounded-md"
                    />
                  </TableCell>
                  <TableCell>
                    <div className="font-medium">{item.titleEn}</div>
                    <div className="text-sm text-muted-foreground truncate max-w-[200px]">
                      {item.descriptionEn}
                    </div>
                  </TableCell>
                  <TableCell>{getCategoryName(item.categoryId)}</TableCell>
                  <TableCell>
                    {item.type === 'food' ? (
                      <div className="flex items-center">
                        <Utensils className="h-4 w-4 mr-1" />
                        Food
                      </div>
                    ) : (
                      <div className="flex items-center">
                        <Coffee className="h-4 w-4 mr-1" />
                        Beverage
                      </div>
                    )}
                  </TableCell>
                  <TableCell>
                    {item.type === 'beverage' && item.beverageSizes ? (
                      <div className="text-sm">
                        <div>From UZS {JSON.parse(item.beverageSizes).small?.price.toLocaleString()}</div>
                      </div>
                    ) : (
                      <div>UZS {item.price.toLocaleString()}</div>
                    )}
                  </TableCell>
                  <TableCell className="text-center">
                    {item.isBestseller && <Star className="h-4 w-4 text-yellow-500 inline" />}
                  </TableCell>
                  <TableCell className="text-center">
                    {item.discountPercentage > 0 ? `${item.discountPercentage}%` : ''}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end items-center gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEditClick(item)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Menu Item</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete this menu item? This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => deleteMutation.mutate(item.id)}
                              className="bg-red-500 hover:bg-red-600"
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-4">
                  No menu items found. Add your first menu item or adjust your search.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {/* Edit Dialog */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Edit Menu Item</DialogTitle>
            <DialogDescription>
              Update the details of this menu item
            </DialogDescription>
          </DialogHeader>
          <MenuItemForm onSubmit={handleEditSubmit} buttonText="Update Menu Item" />
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}