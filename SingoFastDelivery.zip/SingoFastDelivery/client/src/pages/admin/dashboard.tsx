import { useQuery } from '@tanstack/react-query';
import AdminLayout from '@/components/admin/AdminLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Package, ShoppingBag, Users, Truck, ChevronDown, ChevronUp } from 'lucide-react';
import { getQueryFn } from '@/lib/queryClient';

export default function AdminDashboard() {
  const { data: orders = [] } = useQuery({
    queryKey: ['/api/orders'],
    queryFn: getQueryFn({ on401: 'throw' })
  });

  const { data: menuItems = [] } = useQuery({
    queryKey: ['/api/menu'],
    queryFn: getQueryFn({ on401: 'throw' })
  });

  const { data: categories = [] } = useQuery({
    queryKey: ['/api/categories'],
    queryFn: getQueryFn({ on401: 'throw' })
  });

  const { data: users = [] } = useQuery({
    queryKey: ['/api/admin/users'],
    queryFn: getQueryFn({ on401: 'throw' })
  });

  // Order statistics
  const totalOrders = orders.length;
  const pendingOrders = orders.filter(o => o.status === 'pending').length;
  const processingOrders = orders.filter(o => o.status === 'processing').length;
  const deliveredOrders = orders.filter(o => o.status === 'delivered').length;
  
  // Get today's orders
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayOrders = orders.filter(o => {
    const orderDate = new Date(o.createdAt);
    return orderDate >= today;
  });
  
  // Calculate today's revenue
  const todayRevenue = todayOrders.reduce((total, order) => total + order.totalAmount, 0);
  
  // Get yesterday's orders for comparison
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayOrders = orders.filter(o => {
    const orderDate = new Date(o.createdAt);
    return orderDate >= yesterday && orderDate < today;
  });
  
  const yesterdayRevenue = yesterdayOrders.reduce((total, order) => total + order.totalAmount, 0);
  const revenueChange = yesterdayRevenue ? ((todayRevenue - yesterdayRevenue) / yesterdayRevenue) * 100 : 0;

  // Get bestselling products
  const bestsellers = menuItems.filter(item => item.isBestseller).length;

  const StatCard = ({ title, value, icon, change = null, secondaryValue = '' }) => {
    const isPositive = change !== null && change >= 0;
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
          <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center">
            {icon}
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{value}</div>
          {change !== null && (
            <p className="flex items-center text-xs text-muted-foreground">
              {isPositive ? <ChevronUp className="mr-1 h-4 w-4 text-emerald-500" /> : <ChevronDown className="mr-1 h-4 w-4 text-rose-500" />}
              <span className={isPositive ? 'text-emerald-500' : 'text-rose-500'}>
                {Math.abs(change).toFixed(1)}%
              </span>
              <span className="ml-1">{secondaryValue}</span>
            </p>
          )}
        </CardContent>
      </Card>
    );
  };

  return (
    <AdminLayout title="Dashboard">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Today's Revenue"
          value={`UZS ${todayRevenue.toLocaleString()}`}
          icon={<ShoppingBag className="h-4 w-4" />}
          change={revenueChange}
          secondaryValue="vs. yesterday"
        />
        <StatCard
          title="Total Orders"
          value={totalOrders}
          icon={<ShoppingBag className="h-4 w-4" />}
        />
        <StatCard
          title="Pending Orders"
          value={pendingOrders}
          icon={<Truck className="h-4 w-4" />}
        />
        <StatCard
          title="Total Menu Items"
          value={menuItems.length}
          icon={<Package className="h-4 w-4" />}
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 mt-4">
        <Card>
          <CardHeader>
            <CardTitle>Order Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-medium">Pending</span>
                <span className="text-orange-500">{pendingOrders}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Processing</span>
                <span className="text-blue-500">{processingOrders}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Delivered</span>
                <span className="text-green-500">{deliveredOrders}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Menu Details</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-medium">Categories</span>
                <span>{categories.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Menu Items</span>
                <span>{menuItems.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Bestsellers</span>
                <span className="text-yellow-500">{bestsellers}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-medium">Total Users</span>
                <span>{users.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Admins</span>
                <span>{users.filter(u => u.role === 'admin').length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Staff</span>
                <span>{users.filter(u => u.role === 'staff').length}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}