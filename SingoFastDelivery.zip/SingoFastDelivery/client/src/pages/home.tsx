import Header from "@/components/Header";
import SearchBar from "@/components/SearchBar";
import CategorySection from "@/components/CategorySection";
import TrendingProducts from "@/components/TrendingProducts";
import PromoSection from "@/components/PromoSection";
import AboutSection from "@/components/AboutSection";
import DiscountBannerCarousel from "@/components/DiscountBannerCarousel";
import BottomNavigation from "@/components/BottomNavigation";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col pb-16 md:pb-0">
      <Header />
      <main>
        {/* 1. Banners at the top */}
        <DiscountBannerCarousel />
        
        <div className="container mx-auto px-4">
          {/* 2. Search bar below the banners */}
          <SearchBar />
        </div>
        
        {/* 3. Product categories below the search bar */}
        <CategorySection />
        
        {/* 4. Trending products section below the categories */}
        <TrendingProducts />
        
        {/* Additional content */}
        <PromoSection />
        <AboutSection />
      </main>
      
      {/* 5. Menu at the bottom (mobile only) */}
      <BottomNavigation />
      
      <Footer />
    </div>
  );
}
