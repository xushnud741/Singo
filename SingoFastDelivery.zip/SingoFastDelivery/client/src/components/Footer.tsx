import { useTranslation } from "react-i18next";
import { Link } from "wouter";
import { MapPin, Phone, Mail, Twitter, Facebook, Instagram, Youtube } from "lucide-react";
import { Footer as FooterType } from "@shared/types";

export default function Footer() {
  const { t } = useTranslation();
  
  const footerContent: FooterType = {
    companyInfo: t('footer.companyInfo'),
    menu: t('footer.menu'),
    company: t('footer.company'),
    contact: t('footer.contact'),
    workHours: t('footer.workHours'),
    workHoursValue: t('footer.workHoursValue'),
    rights: t('footer.rights'),
    privacy: t('footer.privacy'),
    terms: t('footer.terms')
  };

  return (
    <footer className="bg-[#1A1A1A] text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect width="40" height="40" rx="8" fill="#FF6B35"/>
                <path d="M11 15H29M11 20H29M11 25H29" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
              </svg>
              <div>
                <h2 className="font-montserrat font-bold text-xl text-white">Singo</h2>
                <p className="text-xs text-white/70">Fast Food</p>
              </div>
            </div>
            <p className="text-white/70 mb-6">
              {footerContent.companyInfo}
            </p>
            <div className="flex space-x-4">
              <a href="#" className="bg-white/10 p-2 rounded-full hover:bg-primary transition">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="bg-white/10 p-2 rounded-full hover:bg-primary transition">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="bg-white/10 p-2 rounded-full hover:bg-primary transition">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="bg-white/10 p-2 rounded-full hover:bg-primary transition">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-montserrat font-semibold text-lg mb-6">{footerContent.menu}</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-white/70 hover:text-primary transition">Burgerlar</a></li>
              <li><a href="#" className="text-white/70 hover:text-primary transition">Pizzalar</a></li>
              <li><a href="#" className="text-white/70 hover:text-primary transition">Lavashlar</a></li>
              <li><a href="#" className="text-white/70 hover:text-primary transition">Sendvichlar</a></li>
              <li><a href="#" className="text-white/70 hover:text-primary transition">Ichimliklar</a></li>
              <li><a href="#" className="text-white/70 hover:text-primary transition">Salatlar</a></li>
            </ul>
          </div>

          <div>
            <h3 className="font-montserrat font-semibold text-lg mb-6">{footerContent.company}</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-white/70 hover:text-primary transition">Biz haqimizda</a></li>
              <li><a href="#" className="text-white/70 hover:text-primary transition">Filiallar</a></li>
              <li><a href="#" className="text-white/70 hover:text-primary transition">Aksiyalar</a></li>
              <li><a href="#" className="text-white/70 hover:text-primary transition">Yangiliklar</a></li>
              <li><a href="#" className="text-white/70 hover:text-primary transition">Vakansiyalar</a></li>
              <li><a href="#" className="text-white/70 hover:text-primary transition">FAQ</a></li>
            </ul>
          </div>

          <div>
            <h3 className="font-montserrat font-semibold text-lg mb-6">{footerContent.contact}</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 text-primary mt-0.5 mr-3" />
                <span className="text-white/70">Toshkent sh., Yunusobod tumani, Minor ko'chasi, 23-uy</span>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 text-primary mr-3" />
                <a href="tel:+998712345678" className="text-white/70 hover:text-primary transition">+998 71 234-56-78</a>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 text-primary mr-3" />
                <a href="mailto:info@singo.uz" className="text-white/70 hover:text-primary transition">info@singo.uz</a>
              </li>
            </ul>
            <div className="mt-6">
              <h4 className="font-medium mb-3">{footerContent.workHours}</h4>
              <p className="text-white/70">
                {footerContent.workHoursValue}
              </p>
            </div>
          </div>
        </div>
        <div className="border-t border-white/10 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-white/50 text-sm mb-4 md:mb-0">
              &copy; 2023 Singo Fast Food. {footerContent.rights}
            </p>
            <div className="flex items-center space-x-4">
              <a href="#" className="text-white/50 text-sm hover:text-primary transition">{footerContent.privacy}</a>
              <a href="#" className="text-white/50 text-sm hover:text-primary transition">{footerContent.terms}</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
