import { useState } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { ChevronDown, Languages } from "lucide-react";
import { Language } from "@shared/types";

interface LanguageSelectorProps {
  isLarge?: boolean;
}

const LANGUAGE_NAMES: Record<Language, string> = {
  uz: "UZ",
  ru: "RU",
  en: "EN"
};

const LANGUAGE_FULL_NAMES: Record<Language, string> = {
  uz: "O'zbekcha",
  ru: "Русский",
  en: "English"
};

export default function LanguageSelector({ isLarge }: LanguageSelectorProps = {}) {
  const { language, setLanguage } = useLanguage();
  const [open, setOpen] = useState(false);

  const handleSelect = (lang: Language) => {
    setLanguage(lang);
    setOpen(false);
  };

  if (isLarge) {
    return (
      <div className="grid grid-cols-3 gap-2">
        {(['uz', 'ru', 'en'] as Language[]).map((lang) => (
          <Button
            key={lang}
            variant={language === lang ? "default" : "outline"}
            className={`flex items-center justify-center ${language === lang ? "bg-primary text-white" : ""}`}
            onClick={() => handleSelect(lang)}
          >
            <span className="font-medium">{LANGUAGE_NAMES[lang]}</span>
          </Button>
        ))}
      </div>
    );
  }

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <Button 
          variant="ghost" 
          className="flex items-center text-dark-gray hover:text-primary font-medium transition"
          size="sm"
        >
          <span>{LANGUAGE_NAMES[language]}</span>
          <ChevronDown className="h-4 w-4 ml-1" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-32">
        <DropdownMenuItem 
          className={language === 'uz' ? "text-primary" : "text-dark-gray hover:bg-gray-100"} 
          onClick={() => handleSelect('uz')}
        >
          <span className="font-medium mr-2">UZ</span>
          <span className="text-xs text-muted-foreground">O'zbekcha</span>
        </DropdownMenuItem>
        <DropdownMenuItem 
          className={language === 'ru' ? "text-primary" : "text-dark-gray hover:bg-gray-100"}
          onClick={() => handleSelect('ru')}
        >
          <span className="font-medium mr-2">RU</span>
          <span className="text-xs text-muted-foreground">Русский</span>
        </DropdownMenuItem>
        <DropdownMenuItem 
          className={language === 'en' ? "text-primary" : "text-dark-gray hover:bg-gray-100"}
          onClick={() => handleSelect('en')}
        >
          <span className="font-medium mr-2">EN</span>
          <span className="text-xs text-muted-foreground">English</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
