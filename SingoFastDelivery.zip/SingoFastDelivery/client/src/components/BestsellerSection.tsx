import { useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import FoodCard from "./FoodCard";
import { useLanguage } from "@/contexts/LanguageContext";
import { Bestsellers } from "@shared/types";
import { Skeleton } from "@/components/ui/skeleton";

export default function BestsellerSection() {
  const { t } = useTranslation();
  const { language } = useLanguage();
  
  const bestsellerContent: Bestsellers = {
    title: t('bestsellers.title'),
    viewAll: t('bestsellers.viewAll'),
    bestseller: t('bestsellers.bestseller'),
    discount: t('bestsellers.discount')
  };

  const { data: bestsellerItems, isLoading } = useQuery<any[]>({
    queryKey: ['/api/menu/bestsellers'],
  });

  return (
    <section className="py-12 bg-background">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <h2 className="font-montserrat font-bold text-2xl md:text-3xl text-foreground">{bestsellerContent.title}</h2>
          <Link href="/menu" className="text-primary font-medium flex items-center hover:underline">
            <span>{bestsellerContent.viewAll}</span>
            <ArrowRight className="h-5 w-5 ml-1" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {isLoading ? (
            // Skeleton loading state
            Array(4).fill(0).map((_, i) => (
              <div key={i} className="bg-card rounded-xl shadow-md overflow-hidden dark:border dark:border-gray-700">
                <Skeleton className="w-full h-48" />
                <div className="p-4">
                  <Skeleton className="h-6 w-2/3 mb-2" />
                  <Skeleton className="h-4 w-full mb-3" />
                  <div className="flex justify-between items-center">
                    <Skeleton className="h-6 w-1/3" />
                    <Skeleton className="h-10 w-10 rounded-full" />
                  </div>
                </div>
              </div>
            ))
          ) : (
            bestsellerItems && bestsellerItems.map((item: any) => (
              <FoodCard 
                key={item.id} 
                item={item} 
                language={language}
                bestsellerLabel={bestsellerContent.bestseller}
                discountLabel={bestsellerContent.discount}
              />
            ))
          )}
        </div>
      </div>
    </section>
  );
}
