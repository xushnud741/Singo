import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useCurrency } from "@/contexts/CurrencyContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { formatPrice } from "@/lib/utils";

interface DiscountedProduct {
  id: number;
  title: {
    uz: string;
    ru: string;
    en: string;
  };
  description: {
    uz: string;
    ru: string;
    en: string;
  };
  price: number;
  discountPercentage: number;
  image: string;
  bgColor: string;
}

const discountedProducts: DiscountedProduct[] = [
  {
    id: 1,
    title: {
      uz: "Big Burger Combo",
      ru: "Комбо Биг Бургер",
      en: "Big Burger Combo"
    },
    description: {
      uz: "Katta burger, kartoshka va ichimlik",
      ru: "Большой бургер, картофель и напиток",
      en: "Large burger, fries and drink"
    },
    price: 55000,
    discountPercentage: 20,
    image: "https://img.freepik.com/free-photo/delicious-burger-with-many-ingredients-isolated-white-background-tasty-cheeseburger-splash-sauce_90220-1266.jpg",
    bgColor: "bg-amber-50"
  },
  {
    id: 2,
    title: {
      uz: "Pizza Set",
      ru: "Набор Пицца",
      en: "Pizza Set"
    },
    description: {
      uz: "Katta pizza va 2 ta ichimlik",
      ru: "Большая пицца и 2 напитка",
      en: "Large pizza and 2 drinks"
    },
    price: 80000,
    discountPercentage: 15,
    image: "https://img.freepik.com/free-photo/top-view-pepperoni-pizza-with-mushroom-sausages-bell-pepper-olive-corn-black-wooden_141793-2158.jpg",
    bgColor: "bg-rose-50"
  },
  {
    id: 3,
    title: {
      uz: "Chicken Wings",
      ru: "Куриные Крылышки",
      en: "Chicken Wings"
    },
    description: {
      uz: "12 ta qanotlar va sous",
      ru: "12 крылышек и соус",
      en: "12 wings and sauce"
    },
    price: 65000,
    discountPercentage: 10,
    image: "https://img.freepik.com/free-photo/fried-chicken-wings-with-teriyaki-sauce_2829-19738.jpg",
    bgColor: "bg-orange-50"
  },
  {
    id: 4,
    title: {
      uz: "Sushi Set",
      ru: "Набор Суши",
      en: "Sushi Set"
    },
    description: {
      uz: "24 ta sushi va sous",
      ru: "24 суши и соус",
      en: "24 sushi and sauce"
    },
    price: 120000,
    discountPercentage: 25,
    image: "https://img.freepik.com/free-photo/side-view-sushi-set-with-soy-sauce-chopsticks-wooden-serving-board_176474-3467.jpg",
    bgColor: "bg-emerald-50"
  },
  {
    id: 5,
    title: {
      uz: "Salad Box",
      ru: "Салат Бокс",
      en: "Salad Box"
    },
    description: {
      uz: "Yangi salatlar to'plami",
      ru: "Набор свежих салатов",
      en: "Fresh salad collection"
    },
    price: 40000,
    discountPercentage: 15,
    image: "https://img.freepik.com/free-photo/fresh-vegetable-salad-plate_144627-10820.jpg",
    bgColor: "bg-green-50"
  },
  {
    id: 6,
    title: {
      uz: "Dessert Platter",
      ru: "Десертное Блюдо",
      en: "Dessert Platter"
    },
    description: {
      uz: "4 xil desert va kofe",
      ru: "4 вида десертов и кофе",
      en: "4 types of desserts and coffee"
    },
    price: 70000,
    discountPercentage: 20,
    image: "https://img.freepik.com/free-photo/mixed-cheesecake-strawberry-blueberry-chocolate-sweet-baking_114579-2095.jpg",
    bgColor: "bg-indigo-50"
  }
];

export default function DiscountBannerCarousel() {
  const { t } = useTranslation();
  const { language } = useLanguage();
  const { currency, convertPrice } = useCurrency();
  const [activeIndex, setActiveIndex] = useState(0);
  const [autoplay, setAutoplay] = useState(true);
  
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (autoplay) {
      interval = setInterval(() => {
        setActiveIndex((prev) => (prev + 1) % discountedProducts.length);
      }, 5000);
    }
    
    return () => clearInterval(interval);
  }, [autoplay]);
  
  const handlePrev = () => {
    setAutoplay(false);
    setActiveIndex((prev) => (prev - 1 + discountedProducts.length) % discountedProducts.length);
  };
  
  const handleNext = () => {
    setAutoplay(false);
    setActiveIndex((prev) => (prev + 1) % discountedProducts.length);
  };
  
  const handleDotClick = (index: number) => {
    setAutoplay(false);
    setActiveIndex(index);
  };
  
  const product = discountedProducts[activeIndex];
  const discountedPrice = product.price * (1 - product.discountPercentage / 100);
  
  const getTitle = (product: DiscountedProduct) => {
    return product.title[language] || product.title.en;
  };
  
  const getDescription = (product: DiscountedProduct) => {
    return product.description[language] || product.description.en;
  };

  return (
    <section className="py-6 bg-gradient-to-b from-primary/5 to-transparent">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold mb-6 text-center">{t('discountBanner.title', 'Special Offers')}</h2>
        
        <div className="relative overflow-hidden rounded-2xl shadow-lg border border-primary/10">
          {/* Nav Buttons */}
          <Button 
            variant="ghost" 
            size="icon" 
            className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/80 z-10 rounded-full h-12 w-12 shadow-md"
            onClick={handlePrev}
          >
            <ChevronLeft className="h-6 w-6 text-primary" />
          </Button>
          
          <Button 
            variant="ghost" 
            size="icon" 
            className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/80 z-10 rounded-full h-12 w-12 shadow-md"
            onClick={handleNext}
          >
            <ChevronRight className="h-6 w-6 text-primary" />
          </Button>
          
          {/* Carousel Item */}
          <div 
            className={`flex items-center p-8 md:p-12 min-h-[350px] ${product.bgColor}`}
            key={product.id}
          >
            <div className="flex-1 pr-8">
              <div className="inline-block bg-primary text-white text-sm font-semibold px-4 py-1.5 rounded-full mb-6">
                <span className="animate-pulse">{product.discountPercentage}% {t('discountBanner.off', 'OFF')}</span>
              </div>
              <h3 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">{getTitle(product)}</h3>
              <p className="text-gray-600 mb-6 text-lg max-w-md">{getDescription(product)}</p>
              <div className="flex items-center gap-4 mb-8">
                <span className="text-3xl font-bold text-primary">
                  {formatPrice(convertPrice(discountedPrice), currency)}
                </span>
                <span className="text-gray-500 line-through text-xl">
                  {formatPrice(convertPrice(product.price), currency)}
                </span>
              </div>
              <Button size="lg" className="bg-primary text-white hover:bg-primary/90 shadow-md rounded-full px-8">
                {t('discountBanner.orderNow', 'Order Now')}
              </Button>
            </div>
            <div className="hidden md:flex items-center justify-center w-2/5 relative">
              <div className="absolute -inset-4 rounded-full bg-white/40 blur-xl"></div>
              <img 
                src={product.image} 
                alt={getTitle(product)} 
                className="object-contain w-full h-[250px] rounded-xl z-10 drop-shadow-xl transform transition-transform hover:scale-105 duration-500"
              />
            </div>
          </div>
          
          {/* Dots Navigation */}
          <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex space-x-2">
            {discountedProducts.map((_, index) => (
              <button
                key={index}
                className={`h-3 rounded-full transition-all duration-300 ${
                  index === activeIndex ? 'bg-primary w-10' : 'bg-gray-300 w-3'
                }`}
                onClick={() => handleDotClick(index)}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}