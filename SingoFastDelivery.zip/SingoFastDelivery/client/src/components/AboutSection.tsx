import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Clock, Shield, CreditCard, Users, Sparkles } from "lucide-react";
import { AboutSection as AboutSectionType } from "@shared/types";

export default function AboutSection() {
  const { t } = useTranslation();
  
  const aboutContent: AboutSectionType = {
    aboutTitle: t('about.aboutTitle'),
    aboutHeading: t('about.aboutHeading'),
    description1: t('about.description1'),
    description2: t('about.description2'),
    fastDelivery: t('about.fastDelivery'),
    fastDeliveryDescription: t('about.fastDeliveryDescription'),
    highQuality: t('about.highQuality'),
    highQualityDescription: t('about.highQualityDescription'),
    easyPayment: t('about.easyPayment'),
    easyPaymentDescription: t('about.easyPaymentDescription'),
    customers: t('about.customers'),
    customersDescription: t('about.customersDescription'),
    moreDetails: t('about.moreDetails'),
    experience: t('about.experience'),
    experienceDescription: t('about.experienceDescription')
  };

  return (
    <section className="py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <span className="text-primary font-medium mb-2 block">{aboutContent.aboutTitle}</span>
            <h2 className="font-montserrat font-bold text-3xl text-dark mb-6">{aboutContent.aboutHeading}</h2>
            <p className="text-dark-gray mb-4">
              {aboutContent.description1}
            </p>
            <p className="text-dark-gray mb-6">
              {aboutContent.description2}
            </p>
            <div className="grid grid-cols-2 gap-6 mb-6">
              <div className="flex items-center">
                <Clock className="h-10 w-10 text-primary mr-3" />
                <div>
                  <h3 className="font-bold text-dark">{aboutContent.fastDelivery}</h3>
                  <p className="text-sm text-dark-gray">{aboutContent.fastDeliveryDescription}</p>
                </div>
              </div>
              <div className="flex items-center">
                <Shield className="h-10 w-10 text-primary mr-3" />
                <div>
                  <h3 className="font-bold text-dark">{aboutContent.highQuality}</h3>
                  <p className="text-sm text-dark-gray">{aboutContent.highQualityDescription}</p>
                </div>
              </div>
              <div className="flex items-center">
                <CreditCard className="h-10 w-10 text-primary mr-3" />
                <div>
                  <h3 className="font-bold text-dark">{aboutContent.easyPayment}</h3>
                  <p className="text-sm text-dark-gray">{aboutContent.easyPaymentDescription}</p>
                </div>
              </div>
              <div className="flex items-center">
                <Users className="h-10 w-10 text-primary mr-3" />
                <div>
                  <h3 className="font-bold text-dark">{aboutContent.customers}</h3>
                  <p className="text-sm text-dark-gray">{aboutContent.customersDescription}</p>
                </div>
              </div>
            </div>
            <Button className="bg-primary text-white font-medium py-3 px-8 rounded-full hover:bg-primary/90 transition">
              {aboutContent.moreDetails}
            </Button>
          </div>
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1630343710506-89f324175e9c?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
              alt="Restaurant interior" 
              className="rounded-2xl shadow-lg w-full h-auto"
            />
            <div className="absolute -bottom-4 -left-4 md:-bottom-8 md:-left-8 bg-white p-4 md:p-6 rounded-xl shadow-lg">
              <div className="flex items-center">
                <div className="bg-primary/10 p-3 rounded-full mr-4">
                  <Sparkles className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold text-xl text-dark">{aboutContent.experience}</h3>
                  <p className="text-dark-gray">{aboutContent.experienceDescription}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
