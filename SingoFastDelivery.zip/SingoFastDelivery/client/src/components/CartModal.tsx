import { useTranslation } from "react-i18next";
import { useCart } from "@/contexts/CartContext";
import { useCurrency } from "@/contexts/CurrencyContext";
import { formatPrice } from "@/lib/utils";
import { X, Home, ShoppingBag, Phone, MapPin, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CartModalText, DeliveryOption, PaymentMethod } from "@shared/types";
import { useState, useEffect } from "react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CartModal({ isOpen, onClose }: CartModalProps) {
  const { t } = useTranslation();
  const { 
    cartItems, 
    removeFromCart, 
    isCheckoutMode, 
    setCheckoutMode,
    deliveryOption,
    setDeliveryOption,
    paymentMethod,
    setPaymentMethod,
    orderDetails,
    updateOrderDetails,
    placeOrder
  } = useCart();
  const { currency, convertPrice } = useCurrency();
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const cartText: CartModalText = {
    yourCart: t('cart.yourCart'),
    totalAmount: t('cart.totalAmount'),
    delivery: t('cart.delivery'),
    total: t('cart.total'),
    placeOrder: t('cart.placeOrder'),
    deliveryOptions: t('cart.deliveryOptions'),
    deliveryMethod: t('cart.deliveryMethod'),
    pickupMethod: t('cart.pickupMethod'),
    paymentMethods: t('cart.paymentMethods'),
    cashPayment: t('cart.cashPayment'),
    cardToCardPayment: t('cart.cardToCardPayment'),
    clickPayment: t('cart.clickPayment'),
    paymePayment: t('cart.paymePayment'),
    phoneNumber: t('cart.phoneNumber'),
    address: t('cart.address'),
    notes: t('cart.notes'),
    enterPhone: t('cart.enterPhone'),
    enterAddress: t('cart.enterAddress'),
    enterNotes: t('cart.enterNotes'),
    checkout: t('cart.checkout'),
    continueShopping: t('cart.continueShopping'),
    promoCode: t('cart.promoCode', 'Do you have a promo code?'),
    enterPromoCode: t('cart.enterPromoCode', 'Enter promo code'),
    apply: t('cart.apply', 'Apply')
  };

  const subtotal = cartItems.reduce((sum, item) => {
    // For beverages with custom sizes, use the price for the selected size
    if (item.item.type === 'beverage' && item.selectedSize && item.item.beverageSizes) {
      const beverageSizes = typeof item.item.beverageSizes === 'string' 
        ? JSON.parse(item.item.beverageSizes) 
        : item.item.beverageSizes;
      
      const sizePrice = beverageSizes[item.selectedSize]?.price || item.item.price;
      return sum + item.quantity * convertPrice(sizePrice);
    }
    
    return sum + item.quantity * convertPrice(item.item.price);
  }, 0);
  
  const deliveryFee = cartItems.length > 0 && deliveryOption === 'delivery' ? convertPrice(15000) : 0;
  const total = subtotal + deliveryFee;
  
  // Close checkout mode when cart is closed
  useEffect(() => {
    if (!isOpen && isCheckoutMode) {
      setCheckoutMode(false);
    }
  }, [isOpen, isCheckoutMode, setCheckoutMode]);
  
  const handleDeliveryOptionChange = (value: string) => {
    const option = value as DeliveryOption;
    setDeliveryOption(option);
    updateOrderDetails({ deliveryOption: option });
  };
  
  const handlePaymentMethodChange = (value: string) => {
    const method = value as PaymentMethod;
    setPaymentMethod(method);
    updateOrderDetails({ paymentMethod: method });
  };
  
  const handleInputChange = (field: keyof typeof orderDetails, value: string) => {
    updateOrderDetails({ [field]: value });
  };
  
  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      await placeOrder();
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handlePlaceOrderClick = () => {
    setCheckoutMode(true);
  };
  
  const goBackToCart = () => {
    setCheckoutMode(false);
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent 
        side="right" 
        className="w-full max-w-md p-0 sm:max-w-md h-full flex flex-col"
      >
        <div className="flex justify-between items-center p-4 border-b">
          <SheetTitle className="font-montserrat font-semibold text-xl m-0">
            {isCheckoutMode ? cartText.checkout : cartText.yourCart}
          </SheetTitle>
          <Button 
            variant="ghost"
            size="icon"
            className="p-2 rounded-full hover:bg-muted transition" 
            onClick={onClose}
          >
            <X className="h-6 w-6" />
          </Button>
        </div>
        
        {!isCheckoutMode ? (
          <>
            <div className="flex-1 overflow-y-auto p-4">
              {cartItems.length === 0 ? (
                <div className="text-center py-10">
                  <p className="text-muted-foreground">{t('cart.emptyCart')}</p>
                </div>
              ) : (
                cartItems.map(item => (
                  <div key={item.id} className="flex items-center justify-between py-3 border-b">
                    <div className="flex items-center">
                      <img 
                        src={item.item.image} 
                        alt={item.item.title} 
                        className="w-16 h-16 object-cover rounded-lg mr-3"
                      />
                      <div>
                        <h4 className="font-medium text-foreground">{item.item.title}</h4>
                        {item.selectedSize && item.item.beverageSizes && (
                          <p className="text-xs text-muted-foreground">
                            {typeof item.item.beverageSizes === 'string'
                              ? JSON.parse(item.item.beverageSizes)[item.selectedSize].volume
                              : item.item.beverageSizes[item.selectedSize]?.volume
                            }
                          </p>
                        )}
                        <p className="text-sm text-muted-foreground">
                          {item.quantity} x {
                            item.selectedSize && item.item.beverageSizes
                              ? formatPrice(
                                  convertPrice(
                                    typeof item.item.beverageSizes === 'string'
                                      ? JSON.parse(item.item.beverageSizes)[item.selectedSize].price
                                      : item.item.beverageSizes[item.selectedSize]?.price || item.item.price
                                  ),
                                  currency
                                )
                              : formatPrice(convertPrice(item.item.price), currency)
                          }
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <Button 
                        variant="ghost"
                        size="icon"
                        className="p-1 rounded-full hover:bg-muted transition"
                        onClick={() => removeFromCart(item.id)}
                      >
                        <X className="h-5 w-5 text-muted-foreground" />
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
            <div className="p-4 border-t">
              <div className="mb-4">
                <div className="flex justify-between mb-2">
                  <span className="text-muted-foreground">{cartText.totalAmount}:</span>
                  <span className="font-medium">{formatPrice(subtotal, currency)}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-muted-foreground">{cartText.delivery}:</span>
                  <span className="font-medium">{formatPrice(deliveryFee, currency)}</span>
                </div>
                <div className="flex justify-between pt-2 border-t">
                  <span className="font-semibold">{cartText.total}:</span>
                  <span className="font-bold text-primary">{formatPrice(total, currency)}</span>
                </div>
              </div>
              <Button 
                className="w-full bg-primary text-white font-medium py-3 rounded-full hover:bg-primary/90 transition"
                disabled={cartItems.length === 0}
                onClick={handlePlaceOrderClick}
              >
                {cartText.placeOrder}
              </Button>
            </div>
          </>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto p-4">
              {/* Delivery Options */}
              <div className="mb-6">
                <h4 className="font-medium text-lg mb-3">{cartText.deliveryOptions}</h4>
                <RadioGroup 
                  defaultValue={deliveryOption}
                  value={deliveryOption}
                  onValueChange={handleDeliveryOptionChange}
                  className="flex gap-4"
                >
                  <div className="flex items-center space-x-2 bg-muted/50 dark:bg-gray-800/50 p-3 rounded-lg flex-1">
                    <RadioGroupItem value="delivery" id="delivery" />
                    <Label htmlFor="delivery" className="flex items-center gap-2 cursor-pointer">
                      <ShoppingBag className="h-4 w-4" />
                      <span>{cartText.deliveryMethod}</span>
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 bg-muted/50 dark:bg-gray-800/50 p-3 rounded-lg flex-1">
                    <RadioGroupItem value="pickup" id="pickup" />
                    <Label htmlFor="pickup" className="flex items-center gap-2 cursor-pointer">
                      <Home className="h-4 w-4" />
                      <span>{cartText.pickupMethod}</span>
                    </Label>
                  </div>
                </RadioGroup>
              </div>
              
              {/* Payment Methods */}
              <div className="mb-6">
                <h4 className="font-medium text-lg mb-3">{cartText.paymentMethods}</h4>
                <RadioGroup 
                  defaultValue={paymentMethod}
                  value={paymentMethod}
                  onValueChange={handlePaymentMethodChange}
                  className="grid grid-cols-2 gap-3"
                >
                  <div className="flex items-center space-x-2 bg-muted/50 dark:bg-gray-800/50 p-3 rounded-lg">
                    <RadioGroupItem value="cash" id="cash" />
                    <Label htmlFor="cash" className="cursor-pointer">
                      {cartText.cashPayment}
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 bg-muted/50 dark:bg-gray-800/50 p-3 rounded-lg">
                    <RadioGroupItem value="card-to-card" id="card-to-card" />
                    <Label htmlFor="card-to-card" className="cursor-pointer">
                      {cartText.cardToCardPayment}
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 bg-muted/50 dark:bg-gray-800/50 p-3 rounded-lg">
                    <RadioGroupItem value="click" id="click" />
                    <Label htmlFor="click" className="cursor-pointer">
                      {cartText.clickPayment}
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 bg-muted/50 dark:bg-gray-800/50 p-3 rounded-lg">
                    <RadioGroupItem value="payme" id="payme" />
                    <Label htmlFor="payme" className="cursor-pointer">
                      {cartText.paymePayment}
                    </Label>
                  </div>
                </RadioGroup>
              </div>
              
              {/* Promo Code Section */}
              <div className="mb-6">
                <h4 className="font-medium text-lg mb-3">{cartText.promoCode}</h4>
                <div className="flex gap-2">
                  <Input
                    placeholder={cartText.enterPromoCode}
                    className="flex-1"
                  />
                  <Button variant="outline">
                    {cartText.apply}
                  </Button>
                </div>
              </div>
              
              {/* Contact Information */}
              <div className="mb-6">
                <div className="mb-4">
                  <Label htmlFor="phone" className="flex items-center gap-2 mb-2">
                    <Phone className="h-4 w-4" />
                    {cartText.phoneNumber}
                  </Label>
                  <Input
                    id="phone"
                    placeholder={cartText.enterPhone}
                    value={orderDetails.phone || ''}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    required
                  />
                </div>
                
                {deliveryOption === 'delivery' && (
                  <div className="mb-4">
                    <Label htmlFor="address" className="flex items-center gap-2 mb-2">
                      <MapPin className="h-4 w-4" />
                      {cartText.address}
                    </Label>
                    <Textarea
                      id="address"
                      placeholder={cartText.enterAddress}
                      value={orderDetails.address || ''}
                      onChange={(e) => handleInputChange('address', e.target.value)}
                      required
                    />
                  </div>
                )}
                
                <div>
                  <Label htmlFor="notes" className="flex items-center gap-2 mb-2">
                    <FileText className="h-4 w-4" />
                    {cartText.notes}
                  </Label>
                  <Textarea
                    id="notes"
                    placeholder={cartText.enterNotes}
                    value={orderDetails.notes || ''}
                    onChange={(e) => handleInputChange('notes', e.target.value)}
                  />
                </div>
              </div>
              
              {/* Order Summary */}
              <div className="rounded-lg bg-muted/50 dark:bg-gray-800/50 p-4 mb-4">
                <div className="flex justify-between mb-2">
                  <span className="text-muted-foreground">{cartText.totalAmount}:</span>
                  <span className="font-medium">{formatPrice(subtotal, currency)}</span>
                </div>
                {deliveryOption === 'delivery' && (
                  <div className="flex justify-between mb-2">
                    <span className="text-muted-foreground">{cartText.delivery}:</span>
                    <span className="font-medium">{formatPrice(deliveryFee, currency)}</span>
                  </div>
                )}
                <div className="flex justify-between pt-2 border-t">
                  <span className="font-semibold">{cartText.total}:</span>
                  <span className="font-bold text-primary">{formatPrice(total, currency)}</span>
                </div>
              </div>
            </div>
            
            <div className="p-4 border-t flex gap-3">
              <Button 
                variant="outline"
                className="flex-1"
                onClick={goBackToCart}
              >
                {cartText.continueShopping}
              </Button>
              <Button 
                className="flex-1 bg-primary text-white font-medium hover:bg-primary/90 transition"
                disabled={!orderDetails.phone || (deliveryOption === 'delivery' && !orderDetails.address) || isSubmitting}
                onClick={handleSubmit}
              >
                {cartText.checkout}
              </Button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
