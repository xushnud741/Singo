import { useState } from "react";
import { Star, Plus } from "lucide-react";
import { useCart } from "@/contexts/CartContext";
import { useCurrency } from "@/contexts/CurrencyContext";
import { formatPrice } from "@/lib/utils";
import { Language, BeverageSize, ProductType } from "@shared/types";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

interface FoodCardProps {
  item: {
    id: number;
    titleUz: string;
    titleRu: string;
    titleEn: string;
    descriptionUz: string;
    descriptionRu: string;
    descriptionEn: string;
    price: number;
    image: string;
    isBestseller: boolean;
    discountPercentage: number;
    rating: number;
    type?: ProductType;
    beverageSizes?: string; // JSON string of beverage sizes
  };
  language: Language;
  bestsellerLabel: string;
  discountLabel: string;
}

interface SizeOption {
  value: BeverageSize;
  label: string;
  price: number;
  volume: string;
}

export default function FoodCard({ item, language, bestsellerLabel, discountLabel }: FoodCardProps) {
  const { addToCart } = useCart();
  const { currency, convertPrice } = useCurrency();
  const [selectedSize, setSelectedSize] = useState<BeverageSize | null>(null);
  
  // Parse beverage sizes if available
  const beverageSizes = item.beverageSizes ? JSON.parse(item.beverageSizes) : null;
  const isBeverage = item.type === "beverage" && beverageSizes;
  
  const title = language === 'uz' ? item.titleUz : language === 'ru' ? item.titleRu : item.titleEn;
  const description = language === 'uz' ? item.descriptionUz : language === 'ru' ? item.descriptionRu : item.descriptionEn;
  const titleUz = item.titleUz; // Original Uzbek title for display
  const descriptionUz = item.descriptionUz; // Original Uzbek description for display
  
  // Set the first size as default selected for beverages
  useState(() => {
    if (isBeverage && beverageSizes) {
      setSelectedSize(Object.keys(beverageSizes)[0] as BeverageSize);
    }
  });
  
  // Get size options for beverages
  const sizeOptions: SizeOption[] = isBeverage && beverageSizes
    ? Object.entries(beverageSizes).map(([size, details]: [string, any]) => ({
        value: size as BeverageSize,
        label: size.charAt(0).toUpperCase() + size.slice(1),
        price: details.price,
        volume: details.volume
      }))
    : [];
    
  // Calculate price based on selected size for beverages or regular price for food
  const basePrice = isBeverage && selectedSize && beverageSizes[selectedSize]
    ? beverageSizes[selectedSize].price
    : item.price;
    
  const convertedPrice = convertPrice(basePrice);
  const discountedPrice = item.discountPercentage > 0 
    ? convertPrice(basePrice * (1 - item.discountPercentage / 100)) 
    : null;

  const handleAddToCart = () => {
    addToCart({
      id: item.id,
      quantity: 1,
      selectedSize: isBeverage ? selectedSize as BeverageSize : undefined,
      item: {
        id: item.id,
        title,
        description,
        price: basePrice,
        image: item.image,
        discountPercentage: item.discountPercentage,
        type: item.type,
        titleUz,
        descriptionUz,
        beverageSizes: isBeverage ? beverageSizes : undefined
      }
    });
  };

  const handleSizeChange = (size: BeverageSize) => {
    setSelectedSize(size);
  };

  return (
    <div className="card-premium overflow-hidden group bg-background border border-border rounded-lg shadow-sm hover:shadow-md dark:border-gray-700 dark:shadow-lg transition-all duration-300">
      <div className="relative overflow-hidden">
        <img 
          src={item.image} 
          alt={title} 
          className="w-full h-52 object-cover group-hover:scale-105 transition duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        {(item.isBestseller || item.discountPercentage > 0) && (
          <div className="absolute top-3 right-3 flex flex-col gap-2">
            {item.isBestseller && (
              <Badge className="bg-primary text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg">
                {bestsellerLabel}
              </Badge>
            )}
            {item.discountPercentage > 0 && (
              <Badge className="bg-primary text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg">
                -{item.discountPercentage}%
              </Badge>
            )}
          </div>
        )}
      </div>
      <div className="p-5">
        <div className="flex justify-between items-start mb-3">
          <h3 className="font-montserrat font-semibold text-lg text-foreground">{title}</h3>
          <div className="flex items-center bg-primary/10 dark:bg-primary/20 px-2 py-1 rounded-full">
            <Star className="h-4 w-4 text-primary fill-current" />
            <span className="ml-1 text-sm font-medium">{item.rating.toFixed(1)}</span>
          </div>
        </div>
        
        {/* Always display original Uzbek name and description first */}
        {language !== 'uz' && (
          <div className="mb-2">
            <h4 className="text-sm font-semibold text-foreground/70">{titleUz}</h4>
            <p className="text-xs text-foreground/60 line-clamp-1">{descriptionUz}</p>
          </div>
        )}
        
        <p className="text-muted-foreground text-sm mb-4 line-clamp-2 font-poppins">{description}</p>
        
        {/* Size selection for beverages */}
        {isBeverage && sizeOptions.length > 0 && (
          <div className="mb-4">
            <RadioGroup 
              value={selectedSize || undefined} 
              onValueChange={(value) => handleSizeChange(value as BeverageSize)}
              className="flex space-x-2"
            >
              {sizeOptions.map((option) => (
                <div key={option.value} className="flex items-center space-x-1">
                  <RadioGroupItem 
                    value={option.value} 
                    id={`size-${option.value}`} 
                    className="text-primary"
                  />
                  <Label 
                    htmlFor={`size-${option.value}`}
                    className="text-xs cursor-pointer"
                  >
                    {option.volume}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>
        )}
        
        <div className="flex justify-between items-center">
          <div>
            {discountedPrice ? (
              <div className="flex flex-col">
                <span className="font-montserrat font-bold text-lg text-foreground">
                  {formatPrice(discountedPrice, currency)}
                </span>
                <span className="text-xs text-muted-foreground line-through">
                  {formatPrice(convertedPrice, currency)}
                </span>
              </div>
            ) : (
              <span className="font-montserrat font-bold text-lg text-foreground">
                {formatPrice(convertedPrice, currency)}
              </span>
            )}
          </div>
          <Button 
            onClick={handleAddToCart}
            size="sm"
            className="bg-primary text-white rounded-full hover:bg-primary/90 hover:shadow-md transition-all duration-300 group"
          >
            <Plus className="h-5 w-5 mr-1 group-hover:rotate-90 transition-transform duration-300" />
            <span className="font-medium">Add</span>
          </Button>
        </div>
      </div>
    </div>
  );
}
