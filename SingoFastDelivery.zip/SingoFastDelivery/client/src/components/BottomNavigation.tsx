import { useTranslation } from "react-i18next";
import { Link, useLocation } from "wouter";
import { Home, Search, LayoutGrid, Heart, User } from "lucide-react";
import { cn } from "@/lib/utils";

export default function BottomNavigation() {
  const { t } = useTranslation();
  const [location] = useLocation();

  const navItems = [
    {
      name: t('nav.home') || "Home",
      href: "/",
      icon: Home,
    },
    {
      name: t('nav.search') || "Search",
      href: "/search",
      icon: Search,
    },
    {
      name: t('nav.menu') || "Menu",
      href: "/menu",
      icon: LayoutGrid,
    },
    {
      name: t('nav.favorites') || "Favorites",
      href: "/favorites",
      icon: Heart,
    },
    {
      name: t('nav.profile') || "Profile",
      href: "/profile",
      icon: User,
    },
  ];

  return (
    <div className="fixed bottom-0 left-0 z-50 w-full h-16 bg-background border-t border-muted md:hidden">
      <div className="grid h-full grid-cols-5">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <div key={item.href} className="relative">
              <Link href={item.href}>
                <div
                  className={cn(
                    "inline-flex flex-col items-center justify-center h-full w-full px-1 cursor-pointer group",
                    isActive ? "text-primary" : "text-muted-foreground hover:text-primary/80"
                  )}>
                  <item.icon className={cn(
                    "h-5 w-5 mb-1 transition-colors duration-200",
                    isActive ? "text-primary" : "text-muted-foreground group-hover:text-primary/80"
                  )} />
                  <span className="text-xs truncate">{item.name}</span>
                  
                  {isActive && (
                    <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-6 h-1 bg-primary rounded-t-md"></div>
                  )}
                </div>
              </Link>
            </div>
          );
        })}
      </div>
    </div>
  );
}