import { useEffect, useState } from 'react';
import { useLocation, Link, useRoute } from 'wouter';
import { useAdminAuth } from '@/contexts/AdminAuthContext';
import { Button } from '@/components/ui/button';
import ThemeToggle from '@/components/ThemeToggle';
import {
  LayoutDashboard,
  Menu,
  Package,
  ShoppingCart,
  User,
  Settings,
  ChevronRight,
  LogOut,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface AdminLayoutProps {
  children: React.ReactNode;
  title: string;
}

interface MenuItem {
  title: string;
  href: string;
  icon: React.ReactNode;
}

export default function AdminLayout({ children, title }: AdminLayoutProps) {
  const { user, logout, isAuthenticated } = useAdminAuth();
  const [location, navigate] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/admin/login');
    }
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated || !user) {
    return null;
  }

  const menuItems: MenuItem[] = [
    {
      title: 'Dashboard',
      href: '/admin/dashboard',
      icon: <LayoutDashboard className="h-5 w-5" />,
    },
    {
      title: 'Categories',
      href: '/admin/categories',
      icon: <Package className="h-5 w-5" />,
    },
    {
      title: 'Menu Items',
      href: '/admin/menu-items',
      icon: <Menu className="h-5 w-5" />,
    },
    {
      title: 'Orders',
      href: '/admin/orders',
      icon: <ShoppingCart className="h-5 w-5" />,
    },
  ];

  const isActive = (href: string) => {
    return location === href;
  };

  const handleLogout = () => {
    logout();
    navigate('/admin/login');
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Mobile Header */}
      <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b bg-background px-4 sm:px-6 md:hidden">
        <Button
          variant="ghost"
          size="icon"
          aria-label="Toggle Menu"
          className="md:hidden"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          <Menu className="h-6 w-6" />
        </Button>
        <div className="flex-1">
          <h1 className="text-xl font-semibold">Singo Admin</h1>
        </div>
        <ThemeToggle />
      </header>

      <div className="flex flex-1">
        {/* Sidebar for desktop */}
        <aside className="fixed hidden md:flex h-screen w-64 flex-col border-r bg-background">
          <div className="flex h-16 items-center border-b px-6">
            <Link href="/admin/dashboard" className="flex items-center gap-2 font-semibold">
              <Package className="h-6 w-6" />
              <span className="text-xl">Singo Admin</span>
            </Link>
          </div>
          <nav className="flex-1 overflow-auto py-4">
            <div className="px-4 py-2">
              <h2 className="mb-2 px-2 text-lg font-semibold tracking-tight">
                Menu
              </h2>
              <div className="space-y-1">
                {menuItems.map((item) => (
                  <Button
                    key={item.href}
                    variant={isActive(item.href) ? "default" : "ghost"}
                    className={cn(
                      "w-full justify-start",
                      isActive(item.href) ? "bg-primary text-primary-foreground" : ""
                    )}
                    asChild
                  >
                    <Link href={item.href}>
                      {item.icon}
                      <span className="ml-2">{item.title}</span>
                      {isActive(item.href) && (
                        <ChevronRight className="ml-auto h-4 w-4" />
                      )}
                    </Link>
                  </Button>
                ))}
              </div>
            </div>
          </nav>
          <div className="border-t p-4">
            <div className="flex items-center gap-2 mb-4">
              <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center">
                <User className="h-5 w-5" />
              </div>
              <div>
                <p className="text-sm font-medium">{user.username}</p>
                <p className="text-xs text-muted-foreground">{user.role}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                className="flex-1"
                onClick={handleLogout}
              >
                <LogOut className="mr-2 h-4 w-4" />
                Logout
              </Button>
              <ThemeToggle />
            </div>
          </div>
        </aside>

        {/* Mobile menu */}
        {isMobileMenuOpen && (
          <div className="fixed inset-0 z-40 md:hidden">
            <div className="fixed inset-0 bg-background/80 backdrop-blur-sm" onClick={() => setIsMobileMenuOpen(false)}></div>
            <div className="fixed inset-y-0 left-0 z-40 w-3/4 max-w-xs bg-background p-4 shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold">Singo Admin</h2>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <span className="sr-only">Close</span>
                  <span aria-hidden="true">×</span>
                </Button>
              </div>
              <nav className="space-y-1">
                {menuItems.map((item) => (
                  <Button
                    key={item.href}
                    variant={isActive(item.href) ? "default" : "ghost"}
                    className={cn(
                      "w-full justify-start",
                      isActive(item.href) ? "bg-primary text-primary-foreground" : ""
                    )}
                    asChild
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <Link href={item.href}>
                      {item.icon}
                      <span className="ml-2">{item.title}</span>
                      {isActive(item.href) && (
                        <ChevronRight className="ml-auto h-4 w-4" />
                      )}
                    </Link>
                  </Button>
                ))}
              </nav>
              <div className="mt-4 border-t pt-4">
                <div className="flex items-center gap-2 mb-4">
                  <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center">
                    <User className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">{user.username}</p>
                    <p className="text-xs text-muted-foreground">{user.role}</p>
                  </div>
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full"
                  onClick={handleLogout}
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  Logout
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Main content */}
        <main className="flex-1 md:ml-64 p-4 md:p-8">
          <div className="mb-6">
            <h1 className="text-3xl font-bold tracking-tight hidden md:block">{title}</h1>
          </div>
          {children}
        </main>
      </div>
    </div>
  );
}