import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Hero } from "@shared/types";

export default function HeroSection() {
  const { t } = useTranslation();
  
  const heroContent: Hero = {
    title: t('hero.title'),
    description: t('hero.description'),
    orderNow: t('hero.orderNow'),
    viewMenu: t('hero.viewMenu')
  };

  return (
    <section className="relative py-16 md:py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-r from-primary/95 to-primary/85 z-0"></div>
      
      {/* Decorative elements */}
      <div className="absolute inset-0 overflow-hidden z-0">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-white/10 rounded-full -mr-48 -mt-48 blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-white/5 rounded-full -ml-48 -mb-48 blur-3xl"></div>
        <div className="absolute top-1/2 left-1/4 w-64 h-64 bg-white/5 rounded-full blur-3xl"></div>
        <div className="absolute top-1/4 right-1/3 w-48 h-48 bg-white/5 rounded-full blur-2xl"></div>
        
        {/* Pattern overlay */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(255,255,255,0.1)_1px,_transparent_1px)] bg-[length:20px_20px] opacity-30"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col md:flex-row items-center gap-8 md:gap-16">
          <div className="md:w-1/2 mb-12 md:mb-0 text-white pt-6">
            {/* Premium badge */}
            <div className="inline-block mb-5 bg-white/20 backdrop-blur-sm px-5 py-1.5 rounded-full animate-pulse">
              <span className="text-white font-medium tracking-wide">Premium Food Delivery</span>
            </div>
            
            {/* Hero title */}
            <h1 className="font-montserrat font-black text-4xl md:text-5xl lg:text-6xl leading-tight mb-6 tracking-tight">
              {heroContent.title}
              <div className="mt-3 inline-block relative">
                <span className="relative z-10 text-transparent bg-clip-text bg-gradient-to-r from-white to-white/90">Fast Food</span>
                <div className="absolute bottom-0 left-0 w-full h-3 bg-white/20 -z-0 rounded-full"></div>
              </div>
            </h1>
            
            {/* Hero description */}
            <p className="text-white/90 text-lg md:text-xl mb-10 max-w-lg font-light leading-relaxed">
              {heroContent.description}
            </p>
            
            {/* CTA buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                className="bg-white text-primary hover:bg-white/90 font-semibold py-6 px-8 rounded-full shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 border-b-4 border-white/50"
              >
                {heroContent.orderNow}
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="bg-transparent border-2 border-white text-white font-medium py-6 px-8 rounded-full hover:bg-white/10 transition-all duration-300"
              >
                {heroContent.viewMenu}
              </Button>
            </div>
            
            {/* Stats */}
            <div className="flex flex-wrap items-center mt-16 gap-8">
              <div className="text-center">
                <p className="text-3xl font-bold font-montserrat">15k+</p>
                <p className="text-white/80 text-sm whitespace-nowrap">Happy Customers</p>
              </div>
              <div className="h-10 w-px bg-white/20 hidden sm:block"></div>
              <div className="text-center">
                <p className="text-3xl font-bold font-montserrat">150+</p>
                <p className="text-white/80 text-sm whitespace-nowrap">Menu Items</p>
              </div>
              <div className="h-10 w-px bg-white/20 hidden sm:block"></div>
              <div className="text-center">
                <p className="text-3xl font-bold font-montserrat">50+</p>
                <p className="text-white/80 text-sm whitespace-nowrap">Locations</p>
              </div>
            </div>
          </div>
          
          {/* Hero image area */}
          <div className="md:w-1/2 relative z-10">
            <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-primary/90 to-transparent -left-6 -z-0 md:block hidden rounded-3xl"></div>
            
            {/* Main hero image */}
            <div className="relative">
              {/* Custom food image using SVG for better quality and control */}
              <div className="w-full h-[450px] md:h-[500px] overflow-hidden rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.3)] relative bg-[radial-gradient(circle_at_center,_rgba(0,0,0,0.2)_0px,_transparent_60%)]">
                <svg className="w-full h-full" viewBox="0 0 400 400" xmlns="http://www.w3.org/2000/svg">
                  <defs>
                    <radialGradient id="plate" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
                      <stop offset="0%" stopColor="#ffffff" />
                      <stop offset="100%" stopColor="#f0f0f0" />
                    </radialGradient>
                    <linearGradient id="bun-top" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#ffb347" />
                      <stop offset="100%" stopColor="#ffcc33" />
                    </linearGradient>
                    <linearGradient id="bun-bottom" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#e6a93b" />
                      <stop offset="100%" stopColor="#ffb347" />
                    </linearGradient>
                    <linearGradient id="patty" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#8b4513" />
                      <stop offset="100%" stopColor="#654321" />
                    </linearGradient>
                    <linearGradient id="cheese" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#ffd700" />
                      <stop offset="100%" stopColor="#ffa500" />
                    </linearGradient>
                    <linearGradient id="lettuce" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#32cd32" />
                      <stop offset="100%" stopColor="#228b22" />
                    </linearGradient>
                    <linearGradient id="tomato" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#ff6347" />
                      <stop offset="100%" stopColor="#dc143c" />
                    </linearGradient>
                    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
                      <feDropShadow dx="0" dy="10" stdDeviation="10" floodColor="#000" floodOpacity="0.3" />
                    </filter>
                    <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
                      <feGaussianBlur stdDeviation="5" result="blur" />
                      <feComposite in="SourceGraphic" in2="blur" operator="over" />
                    </filter>
                  </defs>
                  
                  {/* Plate */}
                  <ellipse cx="200" cy="300" rx="150" ry="40" fill="url(#plate)" filter="url(#shadow)" />
                  
                  {/* Burger components from bottom to top */}
                  <ellipse cx="200" cy="250" rx="100" ry="20" fill="url(#bun-bottom)" />
                  <ellipse cx="200" cy="235" rx="105" ry="15" fill="url(#lettuce)" />
                  <ellipse cx="200" cy="225" rx="90" ry="15" fill="url(#patty)" />
                  <ellipse cx="200" cy="215" rx="95" ry="10" fill="url(#cheese)" />
                  <ellipse cx="200" cy="205" rx="85" ry="10" fill="url(#tomato)" />
                  <ellipse cx="200" cy="185" rx="100" ry="25" fill="url(#bun-top)" />
                  
                  {/* Sesame seeds on top bun */}
                  <circle cx="175" cy="175" r="3" fill="#fff" />
                  <circle cx="190" cy="172" r="3" fill="#fff" />
                  <circle cx="205" cy="170" r="3" fill="#fff" />
                  <circle cx="220" cy="172" r="3" fill="#fff" />
                  <circle cx="235" cy="175" r="3" fill="#fff" />
                  <circle cx="180" cy="185" r="3" fill="#fff" />
                  <circle cx="195" cy="182" r="3" fill="#fff" />
                  <circle cx="210" cy="180" r="3" fill="#fff" />
                  <circle cx="225" cy="182" r="3" fill="#fff" />

                  {/* French fries container */}
                  <rect x="75" y="220" width="60" height="80" rx="5" ry="5" fill="#e81c4f" />
                  <rect x="80" y="210" width="50" height="20" rx="5" ry="5" fill="#e81c4f" />
                  
                  {/* French fries */}
                  <rect x="85" y="180" width="5" height="45" rx="2" ry="2" fill="#ffd700" />
                  <rect x="95" y="175" width="5" height="50" rx="2" ry="2" fill="#ffd700" />
                  <rect x="105" y="170" width="5" height="55" rx="2" ry="2" fill="#ffd700" />
                  <rect x="115" y="178" width="5" height="47" rx="2" ry="2" fill="#ffd700" />
                  <rect x="125" y="175" width="5" height="50" rx="2" ry="2" fill="#ffd700" />
                  
                  {/* Soft drink */}
                  <rect x="280" y="170" width="50" height="80" rx="5" ry="5" fill="#1e90ff" filter="url(#glow)" />
                  <rect x="280" y="170" width="50" height="20" rx="5" ry="5" fill="#000" opacity="0.1" />
                  <rect x="290" y="160" width="30" height="15" rx="3" ry="3" fill="#ddd" />
                  <ellipse cx="305" cy="160" rx="15" ry="5" fill="#ddd" />
                  <rect x="303" y="145" width="4" height="15" rx="2" ry="2" fill="#444" />
                </svg>
              </div>
              
              {/* Fast delivery badge */}
              <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-2xl shadow-xl">
                <div className="flex items-center gap-3">
                  <div className="bg-primary/10 p-3 rounded-full">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-sm font-medium">Fast Delivery</p>
                    <p className="text-xs text-gray-500">30 min or less</p>
                  </div>
                </div>
              </div>
              
              {/* Quality badge */}
              <div className="absolute -top-2 -right-2 md:right-4 bg-white p-3 rounded-2xl shadow-xl">
                <div className="flex items-center gap-2">
                  <div className="bg-yellow-100 p-2 rounded-full">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-xs font-medium">Premium Quality</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
