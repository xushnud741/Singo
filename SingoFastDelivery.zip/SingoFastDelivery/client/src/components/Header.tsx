import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Link, useLocation } from "wouter";
import { useLanguage } from "@/contexts/LanguageContext";
import { useCurrency } from "@/contexts/CurrencyContext";
import { useCart } from "@/contexts/CartContext";
import LanguageSelector from "./LanguageSelector";
import CurrencySelector from "./CurrencySelector";
import ThemeToggle from "./ThemeToggle";
import CartModal from "./CartModal";
import SettingsModal from "./SettingsModal";
import { ShoppingBag, Menu, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

const Logo = () => (
  <div className="flex items-center space-x-3">
    <div className="relative">
      <svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="44" height="44" rx="12" fill="currentColor" className="text-primary"/>
        <path d="M13 17H31M13 22H31M13 27H31" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
      </svg>
      <div className="absolute -top-1 -right-1 w-4 h-4 bg-white rounded-full border-2 border-primary"></div>
    </div>
    <div>
      <h1 className="font-montserrat font-bold text-2xl tracking-tight">Singo</h1>
      <p className="text-xs uppercase tracking-widest text-gray-500 font-medium">Fast Food</p>
    </div>
  </div>
);

export default function Header() {
  const { t } = useTranslation();
  const { language } = useLanguage();
  const { currency } = useCurrency();
  const { cartItems, toggleCartOpen, isCartOpen } = useCart();
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [location] = useLocation();

  const navigation = {
    home: t('navigation.home'),
    menu: t('navigation.menu'),
    promotions: t('navigation.promotions'),
    about: t('navigation.about'),
    contact: t('navigation.contact'),
    settings: t('navigation.settings')
  };
  
  const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  
  const toggleSettings = () => {
    setIsSettingsOpen(!isSettingsOpen);
  };

  return (
    <>
      <header className="bg-white/90 dark:bg-gray-950/90 border-b border-border sticky top-0 z-50 backdrop-blur-md transition-all duration-300 shadow-sm">
        <div className="container mx-auto py-4">
          {/* Top header - hidden on mobile */}
          <div className="hidden md:flex items-center justify-end mb-3 gap-6">
            <div className="flex items-center gap-3">
              <LanguageSelector isLarge={false} />
              <div className="h-4 w-px bg-gray-300 dark:bg-gray-700"></div>
              <CurrencySelector isLarge={false} />
              <div className="h-4 w-px bg-gray-300 dark:bg-gray-700"></div>
              <ThemeToggle />
            </div>
          </div>
        
          <div className="flex items-center justify-between">
            <div className="flex-shrink-0">
              <Link href="/">
                <Logo />
              </Link>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center">
              <div className="bg-secondary/50 dark:bg-secondary/30 rounded-full px-2 py-1 flex items-center space-x-1 shadow-inner">
                <Link href="/" className={`font-medium px-4 py-2 rounded-full transition-all duration-300 inline-block ${
                  location === '/' ? 'bg-primary text-white shadow-md' : 'text-foreground/80 hover:text-primary hover:bg-secondary'
                }`}>
                  {navigation.home}
                </Link>
                <Link href="/menu" className={`font-medium px-4 py-2 rounded-full transition-all duration-300 inline-block ${
                  location === '/menu' ? 'bg-primary text-white shadow-md' : 'text-foreground/80 hover:text-primary hover:bg-secondary'
                }`}>
                  {navigation.menu}
                </Link>
                <Link href="/promotions" className={`font-medium px-4 py-2 rounded-full transition-all duration-300 inline-block ${
                  location === '/promotions' ? 'bg-primary text-white shadow-md' : 'text-foreground/80 hover:text-primary hover:bg-secondary'
                }`}>
                  {navigation.promotions}
                </Link>
                <Link href="/about" className={`font-medium px-4 py-2 rounded-full transition-all duration-300 inline-block ${
                  location === '/about' ? 'bg-primary text-white shadow-md' : 'text-foreground/80 hover:text-primary hover:bg-secondary'
                }`}>
                  {navigation.about}
                </Link>
                <Link href="/contact" className={`font-medium px-4 py-2 rounded-full transition-all duration-300 inline-block ${
                  location === '/contact' ? 'bg-primary text-white shadow-md' : 'text-foreground/80 hover:text-primary hover:bg-secondary'
                }`}>
                  {navigation.contact}
                </Link>
              </div>
            </nav>

            {/* Utils */}
            <div className="flex items-center gap-3">
              {/* Settings Button */}
              <Button 
                variant="outline" 
                size="icon"
                className="rounded-full border-primary/20 hover:bg-primary/5 hover:border-primary/40 transition-all duration-300" 
                onClick={toggleSettings}
              >
                <Settings className="h-4 w-4 text-primary" />
              </Button>

              {/* Cart Button */}
              <Button 
                variant="outline" 
                size="icon"
                className="relative rounded-full border-primary/20 hover:bg-primary/5 hover:border-primary/40 transition-all duration-300" 
                onClick={toggleCartOpen}
              >
                <ShoppingBag className="h-4 w-4 text-primary" />
                {totalItems > 0 && (
                  <span className="absolute -top-1 -right-1 bg-primary text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center shadow-sm animate-pulse">
                    {totalItems}
                  </span>
                )}
              </Button>

              {/* Mobile Menu Button */}
              <Sheet>
                <SheetTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="icon"
                    className="md:hidden rounded-full border-primary/20 hover:bg-primary/5 hover:border-primary/40 transition-all duration-300"
                    aria-label="Open Menu"
                  >
                    <Menu className="h-4 w-4 text-primary" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="border-l-0 shadow-2xl bg-background">
                  <div className="mt-6 flex flex-col">
                    <div className="mb-8 flex items-center justify-between">
                      <Logo />
                      <div className="flex items-center gap-2">
                        <LanguageSelector isLarge={false} />
                        <CurrencySelector isLarge={false} />
                        <ThemeToggle />
                      </div>
                    </div>
                    
                    <div className="flex flex-col space-y-2">
                      <Link href="/" className={`font-medium text-lg py-3 px-4 rounded-lg block transition-colors ${
                        location === '/' ? 'bg-primary text-white' : 'hover:bg-secondary transition-colors'
                      }`}>
                        {navigation.home}
                      </Link>
                      <Link href="/menu" className={`font-medium text-lg py-3 px-4 rounded-lg block transition-colors ${
                        location === '/menu' ? 'bg-primary text-white' : 'hover:bg-secondary transition-colors'
                      }`}>
                        {navigation.menu}
                      </Link>
                      <Link href="/promotions" className={`font-medium text-lg py-3 px-4 rounded-lg block transition-colors ${
                        location === '/promotions' ? 'bg-primary text-white' : 'hover:bg-secondary transition-colors'
                      }`}>
                        {navigation.promotions}
                      </Link>
                      <Link href="/about" className={`font-medium text-lg py-3 px-4 rounded-lg block transition-colors ${
                        location === '/about' ? 'bg-primary text-white' : 'hover:bg-secondary transition-colors'
                      }`}>
                        {navigation.about}
                      </Link>
                      <Link href="/contact" className={`font-medium text-lg py-3 px-4 rounded-lg block transition-colors ${
                        location === '/contact' ? 'bg-primary text-white' : 'hover:bg-secondary transition-colors'
                      }`}>
                        {navigation.contact}
                      </Link>
                      <button 
                        className="text-left font-medium text-lg py-3 px-4 rounded-lg block transition-colors hover:bg-secondary"
                        onClick={toggleSettings}
                      >
                        <span className="flex items-center gap-2">
                          <Settings className="h-4 w-4" />
                          {navigation.settings}
                        </span>
                      </button>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </header>

      {/* Cart Modal */}
      <CartModal isOpen={isCartOpen} onClose={toggleCartOpen} />
      
      {/* Settings Modal */}
      <SettingsModal isOpen={isSettingsOpen} onClose={toggleSettings} />
    </>
  );
}
