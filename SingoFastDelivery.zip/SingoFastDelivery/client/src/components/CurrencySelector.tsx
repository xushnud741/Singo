import { useState } from "react";
import { useCurrency } from "@/contexts/CurrencyContext";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { ChevronDown, DollarSign } from "lucide-react";
import { Currency } from "@shared/types";

interface CurrencySelectorProps {
  isLarge?: boolean;
}

const currencies: Currency[] = ["UZS", "RUB", "USD"];

const CURRENCY_SYMBOLS: Record<Currency, string> = {
  UZS: "SO'M",
  RUB: "₽",
  USD: "$"
};

export default function CurrencySelector({ isLarge }: CurrencySelectorProps = {}) {
  const { currency, setCurrency } = useCurrency();
  const [open, setOpen] = useState(false);

  const handleSelect = (curr: Currency) => {
    setCurrency(curr);
    setOpen(false);
  };

  if (isLarge) {
    return (
      <div className="grid grid-cols-3 gap-2">
        {currencies.map((curr) => (
          <Button
            key={curr}
            variant={currency === curr ? "default" : "outline"}
            className={`flex items-center justify-center ${currency === curr ? "bg-primary text-white" : ""}`}
            onClick={() => handleSelect(curr)}
          >
            <span className="font-medium">{curr}</span>
          </Button>
        ))}
      </div>
    );
  }

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <Button 
          variant="ghost" 
          className="flex items-center text-dark-gray hover:text-primary font-medium transition"
          size="sm"
        >
          <span>{currency}</span>
          <ChevronDown className="h-4 w-4 ml-1" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-28">
        {currencies.map(curr => (
          <DropdownMenuItem 
            key={curr}
            className={currency === curr ? "text-primary" : "text-dark-gray hover:bg-gray-100"}
            onClick={() => handleSelect(curr)}
          >
            <span className="font-medium mr-2">{curr}</span>
            <span className="text-xs text-muted-foreground">{CURRENCY_SYMBOLS[curr]}</span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
