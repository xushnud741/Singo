import { useState } from "react";
import { useTranslation } from "react-i18next";
import { X, Phone, MessageSquare, Settings, Moon, Sun, Languages, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useLanguage } from "@/contexts/LanguageContext";
import { useCurrency } from "@/contexts/CurrencyContext";
import { useTheme } from "@/contexts/ThemeContext";
import LanguageSelector from "./LanguageSelector";
import CurrencySelector from "./CurrencySelector";
import ThemeToggle from "./ThemeToggle";

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SettingsModal({ isOpen, onClose }: SettingsModalProps) {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState("appearance");
  const [isChatOpen, setIsChatOpen] = useState(false);
  const { theme } = useTheme();
  
  const settingsText = {
    title: t('settings.title'),
    appearance: t('settings.appearance'),
    language: t('settings.language'),
    currency: t('settings.currency'),
    support: t('settings.support'),
    autoChat: t('settings.autoChat'),
    startChat: t('settings.startChat'),
    typeMessage: t('settings.typeMessage'),
    send: t('settings.send'),
    contactNumber: t('settings.contactNumber')
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="sm:max-w-md">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            {settingsText.title}
          </SheetTitle>
        </SheetHeader>
        
        <Tabs defaultValue="appearance" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-3 mb-6">
            <TabsTrigger value="appearance" className="flex items-center gap-1">
              {theme === 'dark' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
              {settingsText.appearance}
            </TabsTrigger>
            <TabsTrigger value="language" className="flex items-center gap-1">
              <Languages className="h-4 w-4" />
              {settingsText.language}
            </TabsTrigger>
            <TabsTrigger value="support" className="flex items-center gap-1">
              <Phone className="h-4 w-4" />
              {settingsText.support}
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="appearance" className="space-y-4">
            <div className="flex justify-center items-center py-6">
              <ThemeToggle showLabel />
            </div>
          </TabsContent>
          
          <TabsContent value="language" className="space-y-4">
            <div className="py-4">
              <div className="mb-4">
                <h3 className="text-sm font-medium text-foreground/70 mb-2">{settingsText.language}</h3>
                <div className="flex justify-center">
                  <LanguageSelector isLarge />
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-foreground/70 mb-2">{settingsText.currency}</h3>
                <div className="flex justify-center">
                  <CurrencySelector isLarge />
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="support" className="space-y-4">
            <div className="p-4 bg-secondary/40 rounded-lg flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Phone className="h-5 w-5 text-primary" />
                <div>
                  <div className="text-sm text-muted-foreground">{settingsText.contactNumber}</div>
                  <div className="font-medium">+998 77 344 77 03</div>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="gap-1"
                onClick={() => window.open("tel:+998773447703")}
              >
                <Phone className="h-4 w-4" />
                {t('call')}
              </Button>
            </div>
            
            {!isChatOpen ? (
              <Button 
                className="w-full flex items-center gap-2 bg-primary text-white"
                onClick={() => setIsChatOpen(true)}
              >
                <MessageSquare className="h-5 w-5" />
                {settingsText.startChat}
              </Button>
            ) : (
              <div className="border rounded-lg p-3">
                <div className="flex justify-between items-center mb-3">
                  <h4 className="font-medium">{settingsText.autoChat}</h4>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => setIsChatOpen(false)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <div className="bg-secondary/30 rounded-lg p-3 h-40 overflow-y-auto mb-3">
                  <div className="flex flex-col gap-2">
                    <div className="bg-primary/10 text-foreground p-2 rounded-lg rounded-tl-none max-w-[80%] self-start">
                      {t('settings.welcomeMessage')}
                    </div>
                    <div className="bg-primary text-white p-2 rounded-lg rounded-tr-none max-w-[80%] self-end">
                      {t('settings.howCanIHelp')}
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    placeholder={settingsText.typeMessage}
                  />
                  <Button 
                    className="bg-primary text-white"
                  >
                    {settingsText.send}
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </SheetContent>
    </Sheet>
  );
}