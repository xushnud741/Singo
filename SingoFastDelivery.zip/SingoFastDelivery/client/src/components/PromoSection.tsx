import { useTranslation } from "react-i18next";
import { PromoSection as PromoSectionType } from "@shared/types";

export default function PromoSection() {
  const { t } = useTranslation();
  
  const promoContent: PromoSectionType = {
    downloadApp: t('promo.downloadApp'),
    appDescription: t('promo.appDescription'),
    discount: t('promo.discount')
  };

  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <div className="bg-gradient-to-r from-[#2EC4B6]/90 to-[#2EC4B6] rounded-2xl overflow-hidden shadow-lg">
          <div className="flex flex-col lg:flex-row">
            <div className="lg:w-1/2 p-8 md:p-12 flex flex-col justify-center">
              <h2 className="font-montserrat font-bold text-2xl md:text-4xl text-white mb-4">
                {promoContent.downloadApp}
              </h2>
              <p className="text-white/90 text-lg mb-8">
                {promoContent.appDescription} <span className="font-bold">{promoContent.discount}</span>
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <a href="#" className="flex items-center justify-center bg-black text-white rounded-xl px-6 py-3 hover:bg-opacity-80 transition">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 mr-3" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.5775 12.0037C17.5542 9.77906 19.348 8.92072 19.4522 8.86191C18.3224 7.17748 16.5946 6.95566 16.0359 6.93116C14.5584 6.77605 13.1365 7.79514 12.3841 7.79514C11.614 7.79514 10.4564 6.94889 9.22232 6.9793C7.67299 7.00971 6.23097 7.89242 5.4318 9.24735C3.77174 11.9929 4.9969 16.0221 6.58996 18.2032C7.39981 19.2668 8.35182 20.4614 9.59746 20.4146C10.8073 20.3633 11.2769 19.6326 12.7411 19.6326C14.1917 19.6326 14.6335 20.4146 15.8978 20.3859C17.1981 20.3633 18.0116 19.3199 18.7968 18.2467C19.7231 17.0209 20.0978 15.8135 20.1179 15.7436C20.0844 15.7322 17.603 14.7867 17.5775 12.0037Z"/>
                    <path d="M15.6181 4.55375C16.2823 3.73509 16.7405 2.61908 16.6028 1.49121C15.6383 1.53309 14.4483 2.14216 13.7571 2.94469C13.1422 3.6537 12.5892 4.80612 12.7466 5.89661C13.8429 5.97262 14.9305 5.36129 15.6181 4.55375Z"/>
                  </svg>
                  <div>
                    <div className="text-xs">Download on the</div>
                    <div className="text-lg font-semibold -mt-1">App Store</div>
                  </div>
                </a>
                <a href="#" className="flex items-center justify-center bg-black text-white rounded-xl px-6 py-3 hover:bg-opacity-80 transition">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 mr-3" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M4.09 4.22l.027-.036a.423.423 0 0 1 .569-.073l.077.061L12 10.389l7.237-6.217.077-.06a.423.423 0 0 1 .57.072l.026.037v15.558l-.026.036a.423.423 0 0 1-.57.073l-.077-.061L12 13.611l-7.237 6.217-.077.06a.423.423 0 0 1-.57-.072l-.026-.037V4.221zm7.875-2.191L5.128 7.25l-.047 9.364 6.883 5.926V2.03zm6.955 5.029L12.08 2.029v20.511l6.84-5.876V7.06zm-.304-5.309l-6.59 5.46 6.59 5.35V1.75zM11.92 7.21l6.59-5.459V12.12l-6.59-4.91zM5.13 17.96v-10.25l6.79 4.764-6.78 5.486h-.01z"/>
                  </svg>
                  <div>
                    <div className="text-xs">GET IT ON</div>
                    <div className="text-lg font-semibold -mt-1">Google Play</div>
                  </div>
                </a>
              </div>
            </div>
            <div className="lg:w-1/2 relative">
              <img 
                src="https://images.unsplash.com/photo-1623275563389-0f3f1fb05d09?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80"
                alt="Mobile app screenshot" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-[#2EC4B6]/80 to-transparent lg:bg-none"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
