import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface SearchBarProps {
  onSearch?: (searchTerm: string) => void;
}

export default function SearchBar({ onSearch }: SearchBarProps = {}) {
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearch) {
      onSearch(searchTerm);
    }
  };

  return (
    <div className="w-full bg-background mx-auto max-w-5xl -mt-6 relative z-10 rounded-xl shadow-lg">
      <form 
        onSubmit={handleSearch}
        className="flex items-center w-full px-4 py-3"
      >
        <div className="relative flex-1">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <Search className="h-5 w-5 text-muted-foreground" />
          </div>
          <Input
            type="search"
            className="block w-full pl-10 py-6 text-base border-0 focus-visible:ring-primary/50 focus-visible:ring-2 rounded-lg"
            placeholder={t('search.placeholder') || "Search for food..."}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Button 
          type="submit" 
          size="lg"
          className="ml-3 rounded-lg px-6 text-base"
        >
          {t('search.button') || "Search"}
        </Button>
      </form>
    </div>
  );
}