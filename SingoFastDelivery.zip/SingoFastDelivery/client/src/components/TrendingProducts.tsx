import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useLanguage } from "@/contexts/LanguageContext";
import { useCurrency } from "@/contexts/CurrencyContext";
import { useCart } from "@/contexts/CartContext";
import { formatPrice } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Star, ShoppingCart, TrendingUp } from "lucide-react";

interface TrendingProductsProps {
  limit?: number;
}

export default function TrendingProducts({ limit = 6 }: TrendingProductsProps) {
  const { t } = useTranslation();
  const { language } = useLanguage();
  const { currency, convertPrice } = useCurrency();
  const { addToCart } = useCart();
  const [trendingProducts, setTrendingProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchTrendingProducts() {
      setLoading(true);
      try {
        const res = await apiRequest('GET', '/api/menu/bestsellers');
        const data = await res.json();
        setTrendingProducts(data.slice(0, limit));
      } catch (error) {
        console.error('Failed to fetch trending products', error);
      } finally {
        setLoading(false);
      }
    }

    fetchTrendingProducts();
  }, [limit]);

  // Get title based on language
  const getTitle = (product: any) => {
    switch (language) {
      case 'uz':
        return product.titleUz || product.title;
      case 'ru':
        return product.titleRu || product.title;
      case 'en':
      default:
        return product.titleEn || product.title;
    }
  };

  // Get description based on language
  const getDescription = (product: any) => {
    switch (language) {
      case 'uz':
        return product.descriptionUz || product.description;
      case 'ru':
        return product.descriptionRu || product.description;
      case 'en':
      default:
        return product.descriptionEn || product.description;
    }
  };

  const handleAddToCart = (product: any) => {
    addToCart({
      id: Date.now(),
      quantity: 1,
      item: {
        id: product.id,
        title: getTitle(product),
        description: getDescription(product),
        price: product.price,
        image: product.image,
        discountPercentage: product.discountPercentage || 0,
        type: product.type,
        titleUz: product.titleUz,
        descriptionUz: product.descriptionUz,
        beverageSizes: product.beverageSizes,
      },
    });
  };

  if (loading) {
    return (
      <section className="py-10 px-4">
        <div className="container mx-auto">
          <div className="flex justify-between items-center mb-8">
            <Skeleton className="h-10 w-48" />
            <Skeleton className="h-8 w-24" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array(limit).fill(0).map((_, index) => (
              <Skeleton key={index} className="h-80 rounded-2xl" />
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-10 px-4 bg-muted/30">
      <div className="container mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-3">
            <div className="bg-primary/10 p-2 rounded-full">
              <TrendingUp className="h-5 w-5 text-primary" />
            </div>
            <h2 className="text-2xl md:text-3xl font-bold">
              {t('trendingProducts.title') || "Trending Now"}
            </h2>
          </div>
          <Button variant="link" className="text-primary font-medium">
            {t('trendingProducts.viewAll') || "View All"}
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {trendingProducts.map((product) => (
            <div 
              key={product.id} 
              className="bg-background rounded-2xl overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300 group"
            >
              <div className="relative h-48 overflow-hidden">
                {product.image ? (
                  <img 
                    src={product.image} 
                    alt={getTitle(product)} 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-muted">
                    <ShoppingCart className="h-12 w-12 text-muted-foreground/50" />
                  </div>
                )}
                
                {/* Badges */}
                <div className="absolute top-3 left-3 flex flex-col gap-2">
                  {product.isBestseller && (
                    <Badge className="bg-amber-500 hover:bg-amber-500/90 text-white px-3 py-1">
                      {t('bestseller.label') || "Bestseller"}
                    </Badge>
                  )}
                  {product.discountPercentage > 0 && (
                    <Badge className="bg-red-500 hover:bg-red-500/90 text-white px-3 py-1">
                      {t('discount.label', { percent: product.discountPercentage }) || `-${product.discountPercentage}%`}
                    </Badge>
                  )}
                </div>
              </div>
              
              <div className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold text-lg leading-tight">
                    {getTitle(product)}
                  </h3>
                  <div className="flex items-center gap-1 text-amber-500">
                    <Star className="h-4 w-4 fill-current" />
                    <span className="text-sm font-medium">{product.rating || "4.5"}</span>
                  </div>
                </div>
                
                <p className="text-muted-foreground text-sm line-clamp-2 mb-4">
                  {getDescription(product)}
                </p>
                
                <div className="flex justify-between items-center">
                  <div>
                    {product.discountPercentage > 0 ? (
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-bold">
                          {formatPrice(convertPrice(product.price * (1 - product.discountPercentage / 100)), currency)}
                        </span>
                        <span className="text-sm text-muted-foreground line-through">
                          {formatPrice(convertPrice(product.price), currency)}
                        </span>
                      </div>
                    ) : (
                      <span className="text-lg font-bold">
                        {formatPrice(convertPrice(product.price), currency)}
                      </span>
                    )}
                  </div>
                  
                  <Button 
                    size="sm" 
                    onClick={() => handleAddToCart(product)}
                    className="rounded-full px-4"
                  >
                    <ShoppingCart className="h-4 w-4 mr-2" />
                    {t('addToCart') || "Add"}
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}