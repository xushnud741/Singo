import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { useLanguage } from "@/contexts/LanguageContext";
import { useCurrency } from "@/contexts/CurrencyContext";
import { useCart } from "@/contexts/CartContext";
import { formatPrice } from "@/lib/utils";
import { MenuSection } from "@shared/types";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export default function CategorySection() {
  const { t } = useTranslation();
  const { language } = useLanguage();
  const { currency, convertPrice } = useCurrency();
  const { addToCart } = useCart();
  
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const menuText: MenuSection = {
    title: t('menu.title'),
    all: t('menu.all')
  };

  // Fetch categories
  const { data: categories = [], isLoading: categoriesLoading } = useQuery<any[]>({
    queryKey: ['/api/categories'],
  });

  // Fetch menu items
  const { data: menuItems = [], isLoading: menuItemsLoading } = useQuery<any[]>({
    queryKey: ['/api/menu', selectedCategory],
  });

  useEffect(() => {
    if (categories.length > 0 && !selectedCategory) {
      setSelectedCategory('all');
    }
  }, [categories, selectedCategory]);

  const handleCategoryChange = (categorySlug: string) => {
    setSelectedCategory(categorySlug);
  };

  const getCategoryName = (category: any) => {
    if (language === 'uz') return category.nameUz;
    if (language === 'ru') return category.nameRu;
    return category.nameEn;
  };

  const getItemTitle = (item: any) => {
    if (language === 'uz') return item.titleUz;
    if (language === 'ru') return item.titleRu;
    return item.titleEn;
  };

  const getItemDescription = (item: any) => {
    if (language === 'uz') return item.descriptionUz;
    if (language === 'ru') return item.descriptionRu;
    return item.descriptionEn;
  };

  const handleAddToCart = (item: any) => {
    addToCart({
      id: item.id,
      quantity: 1,
      item: {
        id: item.id,
        title: getItemTitle(item),
        description: getItemDescription(item),
        price: item.price,
        image: item.image,
        discountPercentage: item.discountPercentage
      }
    });
  };

  return (
    <section className="py-12 bg-secondary/10 dark:bg-gray-900/30">
      <div className="container mx-auto px-4">
        <h2 className="font-montserrat font-bold text-2xl md:text-3xl text-foreground mb-8">{menuText.title}</h2>
        
        {/* Categories Tabs */}
        <div className="mb-8">
          <div className="flex flex-nowrap overflow-x-auto pb-2 scrollbar-hide">
            <Button 
              onClick={() => handleCategoryChange('all')}
              className={`whitespace-nowrap py-2 px-6 rounded-full mr-3 ${
                selectedCategory === 'all' 
                  ? 'bg-primary text-white' 
                  : 'bg-card text-muted-foreground hover:bg-muted/90'
              }`}
            >
              {menuText.all}
            </Button>
            
            {categoriesLoading ? (
              // Skeleton for categories
              Array(5).fill(0).map((_, i) => (
                <Skeleton key={i} className="whitespace-nowrap h-10 w-28 rounded-full mr-3" />
              ))
            ) : (
              categories.map((category: any) => (
                <Button 
                  key={category.id}
                  onClick={() => handleCategoryChange(category.slug)}
                  className={`whitespace-nowrap py-2 px-6 rounded-full mr-3 ${
                    selectedCategory === category.slug 
                      ? 'bg-primary text-white' 
                      : 'bg-card text-muted-foreground hover:bg-muted/90'
                  }`}
                >
                  {getCategoryName(category)}
                </Button>
              ))
            )}
          </div>
        </div>

        {/* Menu Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {menuItemsLoading ? (
            // Skeleton for menu items
            Array(6).fill(0).map((_, i) => (
              <div key={i} className="bg-card rounded-xl shadow-sm dark:border dark:border-gray-700 p-4">
                <div className="flex">
                  <Skeleton className="w-28 h-28 rounded-lg mr-4" />
                  <div className="flex flex-col flex-grow">
                    <Skeleton className="h-6 w-2/3 mb-1" />
                    <Skeleton className="h-4 w-full mb-auto" />
                    <div className="flex justify-between items-center mt-3">
                      <Skeleton className="h-6 w-1/3" />
                      <Skeleton className="h-10 w-10 rounded-full" />
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            menuItems.map((item: any) => (
              <div key={item.id} className="bg-card rounded-xl shadow-sm hover:shadow-md transition p-4 dark:border dark:border-gray-700">
                <div className="flex">
                  <img 
                    src={item.image} 
                    alt={getItemTitle(item)} 
                    className="w-28 h-28 object-cover rounded-lg mr-4"
                  />
                  <div className="flex flex-col flex-grow">
                    <h3 className="font-montserrat font-semibold text-lg text-foreground mb-1">{getItemTitle(item)}</h3>
                    <p className="text-muted-foreground text-sm mb-auto line-clamp-2">{getItemDescription(item)}</p>
                    <div className="flex justify-between items-center mt-3">
                      <span className="font-montserrat font-semibold text-foreground">
                        {formatPrice(convertPrice(item.price), currency)}
                      </span>
                      <Button 
                        onClick={() => handleAddToCart(item)}
                        size="icon"
                        className="bg-primary text-white p-2 rounded-full hover:bg-primary/90 transition"
                      >
                        <Plus className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Pagination - can be implemented later for larger menus */}
      </div>
    </section>
  );
}
