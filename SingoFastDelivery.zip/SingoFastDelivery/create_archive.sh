#!/bin/bash

# Create a temporary directory for organizing files
mkdir -p singo_fast_food_app

# Copy configuration files
cp package.json tsconfig.json vite.config.ts postcss.config.js tailwind.config.ts theme.json drizzle.config.ts README.md INSTALLATION_GUIDE.md PROJECT_DELIVERY.md singo_fast_food_app/

# Create directory structure
mkdir -p singo_fast_food_app/client/src
mkdir -p singo_fast_food_app/server
mkdir -p singo_fast_food_app/server/utils
mkdir -p singo_fast_food_app/shared

# Copy client files
cp -r client/index.html singo_fast_food_app/client/
cp -r client/src/* singo_fast_food_app/client/src/

# Copy server files
cp server/*.ts singo_fast_food_app/server/
cp -r server/utils/* singo_fast_food_app/server/utils/

# Copy shared files
cp shared/*.ts singo_fast_food_app/shared/

# Create the zip archive
zip -r singo_fast_food_app.zip singo_fast_food_app

# Clean up
rm -rf singo_fast_food_app

echo "Archive created: singo_fast_food_app.zip"