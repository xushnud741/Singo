export type ProductType = 'food' | 'beverage';
export type BeverageSize = 'small' | 'medium' | 'large';
export type DeliveryOption = 'delivery' | 'pickup';
export type PaymentMethod = 'cash' | 'card-to-card' | 'click' | 'payme';

export interface CartItem {
  id: number;
  quantity: number;
  selectedSize?: BeverageSize;
  item: {
    id: number;
    title: string;
    description: string;
    price: number;
    image: string;
    discountPercentage: number;
    type?: ProductType;
    titleUz?: string;
    descriptionUz?: string;
    beverageSizes?: string | {
      [key in BeverageSize]?: { volume: string; price: number };
    };
  };
}

export interface OrderDetails {
  deliveryOption: DeliveryOption;
  paymentMethod: PaymentMethod;
  address?: string;
  phone: string;
  notes?: string;
}

export type Language = 'uz' | 'ru' | 'en';
export type Currency = 'UZS' | 'RUB' | 'USD';

export const CURRENCY_CONVERSION = {
  UZS: 1,
  RUB: 0.0075, // 1 UZS = 0.0075 RUB
  USD: 0.000081 // 1 UZS = 0.000081 USD
};

export type Navigation = {
  home: string;
  menu: string;
  promotions: string;
  about: string;
  contact: string;
};

export type Footer = {
  companyInfo: string;
  menu: string;
  company: string;
  contact: string;
  workHours: string;
  workHoursValue: string;
  rights: string;
  privacy: string;
  terms: string;
};

export type Hero = {
  title: string;
  description: string;
  orderNow: string;
  viewMenu: string;
};

export type Bestsellers = {
  title: string;
  viewAll: string;
  bestseller: string;
  discount: string;
};

export type MenuSection = {
  title: string;
  all: string;
};

export type AboutSection = {
  aboutTitle: string;
  aboutHeading: string;
  description1: string;
  description2: string;
  fastDelivery: string;
  fastDeliveryDescription: string;
  highQuality: string;
  highQualityDescription: string;
  easyPayment: string;
  easyPaymentDescription: string;
  customers: string;
  customersDescription: string;
  moreDetails: string;
  experience: string;
  experienceDescription: string;
};

export type PromoSection = {
  downloadApp: string;
  appDescription: string;
  discount: string;
};

export type CartModalText = {
  yourCart: string;
  totalAmount: string;
  delivery: string;
  total: string;
  placeOrder: string;
  deliveryOptions: string;
  deliveryMethod: string;
  pickupMethod: string;
  paymentMethods: string;
  cashPayment: string;
  cardToCardPayment: string;
  clickPayment: string;
  paymePayment: string;
  phoneNumber: string;
  address: string;
  notes: string;
  enterPhone: string;
  enterAddress: string;
  enterNotes: string;
  checkout: string;
  continueShopping: string;
  promoCode: string;
  enterPromoCode: string;
  apply: string;
};
