# Singo Fast Food Delivery Platform

A premium multilingual food delivery platform for Singo Fast Food, offering seamless international ordering with multiple currency support and enhanced user experience.

## Features

- **Multilingual Support**: Uzbek (default), Russian, and English languages
- **Multi-Currency**: UZS (default), RUB, and USD with automatic conversion
- **Light/Dark Mode**: Toggle between light and dark themes
- **Dynamic Product Catalog**: Categories, bestsellers, and trending items
- **Shopping Cart**: Add items, adjust quantities, and checkout
- **Delivery Options**: Choose between delivery and pickup
- **Payment Methods**: Cash, Card-to-Card, Click, and Payme
- **Admin Panel**: Manage categories, menu items, and orders
- **Telegram Notifications**: Receive order notifications via Telegram

## Installation

1. Extract the zip archive:
   ```
   unzip singo_fast_food_app.zip
   cd singo_fast_food_app
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Start the development server:
   ```
   npm run dev
   ```

4. Access the application:
   - Frontend: http://localhost:5000
   - Admin Panel: http://localhost:5000/admin/login (default credentials: admin/admin)

## Project Structure

```
singo_fast_food_app/
├── client/              # Frontend React application
│   ├── src/
│   │   ├── components/  # UI components
│   │   ├── contexts/    # React context providers
│   │   ├── hooks/       # Custom React hooks
│   │   ├── lib/         # Utility functions and API client
│   │   ├── pages/       # Page components and routing
│   │   └── ...
├── server/              # Backend Express server
│   ├── utils/           # Server utility functions
│   ├── index.ts         # Server entry point
│   ├── routes.ts        # API route definitions
│   └── storage.ts       # Data storage implementation
├── shared/              # Shared types and schemas
│   ├── schema.ts        # Database schema definitions
│   └── types.ts         # TypeScript type declarations
└── ... (configuration files)
```

## Key Technologies

- **Frontend**: React, TypeScript, Tailwind CSS, shadcn/ui
- **Backend**: Express, Node.js
- **State Management**: React Context API, TanStack Query
- **Internationalization**: i18next
- **Styling**: Tailwind CSS with shadcn/ui components

## License

All rights reserved © Singo Fast Food, 2025.