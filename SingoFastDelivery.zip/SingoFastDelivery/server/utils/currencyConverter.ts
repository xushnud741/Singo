import { CURRENCY_CONVERSION } from '@shared/types';

// Convert from one currency to another
export function convertCurrency(
  amount: number, 
  from: string, 
  to: string
): number {
  // Normalize input to uppercase
  const fromCurrency = from.toUpperCase();
  const toCurrency = to.toUpperCase();
  
  // Check if currencies are supported
  if (!(fromCurrency in CURRENCY_CONVERSION) || !(toCurrency in CURRENCY_CONVERSION)) {
    throw new Error(`Unsupported currency: ${fromCurrency} or ${toCurrency}`);
  }
  
  // Direct conversion if both are the same
  if (fromCurrency === toCurrency) {
    return amount;
  }
  
  // Convert to UZS first if the source is not UZS
  const amountInUZS = fromCurrency === 'UZS' 
    ? amount 
    : amount / CURRENCY_CONVERSION[fromCurrency as keyof typeof CURRENCY_CONVERSION];
    
  // Convert from UZS to target currency
  return amountInUZS * CURRENCY_CONVERSION[toCurrency as keyof typeof CURRENCY_CONVERSION];
}
