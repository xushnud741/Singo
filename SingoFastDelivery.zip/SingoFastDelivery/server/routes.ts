import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { convertCurrency } from "./utils/currencyConverter";
import { 
  insertOrderSchema, 
  insertTelegramConfigSchema, 
  insertCategorySchema,
  insertMenuItemSchema,
  insertUserSchema,
  type OrderStatus
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  app.get('/api/menu/bestsellers', async (req, res) => {
    try {
      const bestsellers = await storage.getBestsellers();
      res.json(bestsellers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bestsellers" });
    }
  });

  app.get('/api/categories', async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.get('/api/menu', async (req, res) => {
    try {
      const categorySlug = req.query.categorySlug as string;
      let menuItems;
      
      if (categorySlug && categorySlug !== 'all') {
        menuItems = await storage.getMenuItemsByCategory(categorySlug);
      } else {
        menuItems = await storage.getMenuItems();
      }
      
      res.json(menuItems);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch menu items" });
    }
  });

  app.get('/api/convert-currency', (req, res) => {
    const { amount, from, to } = req.query;
    
    if (!amount || !from || !to) {
      return res.status(400).json({ 
        message: "Missing required parameters: amount, from, to" 
      });
    }
    
    try {
      const result = convertCurrency(
        Number(amount), 
        from as string, 
        to as string
      );
      
      res.json({ result });
    } catch (error) {
      res.status(500).json({ message: "Failed to convert currency" });
    }
  });
  
  // Order API routes
  app.get('/api/orders', async (req, res) => {
    try {
      const orders = await storage.getOrders();
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });
  
  app.get('/api/orders/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }
      
      const order = await storage.getOrder(id);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch order" });
    }
  });
  
  app.post('/api/orders', async (req, res) => {
    try {
      const parseResult = insertOrderSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid order data", 
          errors: parseResult.error.format() 
        });
      }
      
      const order = await storage.createOrder(parseResult.data);
      
      // If telegram notification is enabled, send notification here
      const telegramConfig = await storage.getTelegramConfig();
      if (telegramConfig?.notifyOnNewOrder) {
        // Implement telegram notification logic here
        console.log(`Telegram notification would be sent to ${telegramConfig.chatId} for new order`);
      }
      
      res.status(201).json(order);
    } catch (error) {
      res.status(500).json({ message: "Failed to create order" });
    }
  });
  
  app.patch('/api/orders/:id/status', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }
      
      const status = req.body.status as OrderStatus;
      if (!status || !['pending', 'processing', 'out_for_delivery', 'delivered', 'cancelled'].includes(status)) {
        return res.status(400).json({ message: "Invalid order status" });
      }
      
      const order = await storage.updateOrderStatus(id, status);
      
      // If telegram notification is enabled, send notification here
      const telegramConfig = await storage.getTelegramConfig();
      if (telegramConfig?.notifyOnStatusChange) {
        // Implement telegram notification logic here
        console.log(`Telegram notification would be sent to ${telegramConfig.chatId} for order status change to ${status}`);
      }
      
      res.json(order);
    } catch (error: any) {
      if (error.message.includes("not found")) {
        return res.status(404).json({ message: error.message });
      }
      res.status(500).json({ message: "Failed to update order status" });
    }
  });
  
  // Telegram Config API routes
  app.get('/api/telegram-config', async (req, res) => {
    try {
      const config = await storage.getTelegramConfig();
      if (!config) {
        return res.status(404).json({ message: "Telegram configuration not found" });
      }
      res.json(config);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch Telegram configuration" });
    }
  });
  
  app.post('/api/telegram-config', async (req, res) => {
    try {
      const parseResult = insertTelegramConfigSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid Telegram configuration data", 
          errors: parseResult.error.format() 
        });
      }
      
      const config = await storage.saveTelegramConfig(parseResult.data);
      res.status(201).json(config);
    } catch (error) {
      res.status(500).json({ message: "Failed to save Telegram configuration" });
    }
  });

  // Admin API Routes for Categories
  app.post('/api/admin/categories', async (req, res) => {
    try {
      const parseResult = insertCategorySchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid category data", 
          errors: parseResult.error.format() 
        });
      }
      
      const category = await storage.createCategory(parseResult.data);
      res.status(201).json(category);
    } catch (error) {
      res.status(500).json({ message: "Failed to create category" });
    }
  });

  app.put('/api/admin/categories/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid category ID" });
      }
      
      const parseResult = insertCategorySchema.partial().safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid category data", 
          errors: parseResult.error.format() 
        });
      }
      
      const category = await storage.updateCategory(id, parseResult.data);
      res.json(category);
    } catch (error: any) {
      if (error.message?.includes("not found")) {
        return res.status(404).json({ message: error.message });
      }
      res.status(500).json({ message: "Failed to update category" });
    }
  });

  app.delete('/api/admin/categories/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid category ID" });
      }
      
      await storage.deleteCategory(id);
      res.status(204).send();
    } catch (error: any) {
      if (error.message?.includes("not found")) {
        return res.status(404).json({ message: error.message });
      }
      res.status(500).json({ message: "Failed to delete category" });
    }
  });

  // Admin API Routes for Menu Items
  app.get('/api/admin/menu/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid menu item ID" });
      }
      
      const menuItem = await storage.getMenuItem(id);
      if (!menuItem) {
        return res.status(404).json({ message: "Menu item not found" });
      }
      
      res.json(menuItem);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch menu item" });
    }
  });

  app.post('/api/admin/menu', async (req, res) => {
    try {
      const parseResult = insertMenuItemSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid menu item data", 
          errors: parseResult.error.format() 
        });
      }
      
      const menuItem = await storage.createMenuItem(parseResult.data);
      res.status(201).json(menuItem);
    } catch (error) {
      res.status(500).json({ message: "Failed to create menu item" });
    }
  });

  app.put('/api/admin/menu/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid menu item ID" });
      }
      
      const parseResult = insertMenuItemSchema.partial().safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid menu item data", 
          errors: parseResult.error.format() 
        });
      }
      
      const menuItem = await storage.updateMenuItem(id, parseResult.data);
      res.json(menuItem);
    } catch (error: any) {
      if (error.message?.includes("not found")) {
        return res.status(404).json({ message: error.message });
      }
      res.status(500).json({ message: "Failed to update menu item" });
    }
  });

  app.delete('/api/admin/menu/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid menu item ID" });
      }
      
      await storage.deleteMenuItem(id);
      res.status(204).send();
    } catch (error: any) {
      if (error.message?.includes("not found")) {
        return res.status(404).json({ message: error.message });
      }
      res.status(500).json({ message: "Failed to delete menu item" });
    }
  });

  // User management routes
  app.get('/api/admin/users', async (req, res) => {
    try {
      const users = await storage.getUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.post('/api/admin/users', async (req, res) => {
    try {
      const parseResult = insertUserSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid user data", 
          errors: parseResult.error.format() 
        });
      }
      
      const user = await storage.createUser(parseResult.data);
      res.status(201).json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  app.put('/api/admin/users/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const parseResult = insertUserSchema.partial().safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid user data", 
          errors: parseResult.error.format() 
        });
      }
      
      const user = await storage.updateUser(id, parseResult.data);
      res.json(user);
    } catch (error: any) {
      if (error.message?.includes("not found")) {
        return res.status(404).json({ message: error.message });
      }
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  app.delete('/api/admin/users/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      await storage.deleteUser(id);
      res.status(204).send();
    } catch (error: any) {
      if (error.message?.includes("not found")) {
        return res.status(404).json({ message: error.message });
      }
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  // Basic authentication
  app.post('/api/login', async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      res.json({ 
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        isActive: user.isActive
      });
    } catch (error) {
      res.status(500).json({ message: "Authentication failed" });
    }
  });
  
  // Admin authentication
  app.post('/api/admin/login', async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      // Check if user has admin or staff role
      if (!user.role || (user.role !== 'admin' && user.role !== 'staff')) {
        return res.status(403).json({ message: "You don't have permission to access the admin panel" });
      }
      
      // Check if user is active
      if (!user.isActive) {
        return res.status(403).json({ message: "Your account is not active. Please contact an administrator." });
      }
      
      // Return user info with JWT token (in a real app)
      res.json({ 
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          role: user.role,
          isActive: user.isActive
        },
        token: "jwt-token-would-be-here-in-a-real-app"
      });
    } catch (error) {
      res.status(500).json({ message: "Authentication failed" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
