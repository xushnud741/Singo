import { 
  users, type User, type InsertUser, 
  categories, type Category, type InsertCategory,
  menuItems, type MenuItem, type InsertMenuItem, 
  orders, type Order, type InsertOrder, type OrderStatus,
  telegramConfig, type TelegramConfig, type InsertTelegramConfig
} from "@shared/schema";
import { ProductType } from "@shared/types";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUsers(): Promise<User[]>;
  updateUser(id: number, user: Partial<User>): Promise<User>;
  deleteUser(id: number): Promise<void>;
  
  // Category methods
  getCategories(): Promise<Category[]>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: Partial<Category>): Promise<Category>;
  deleteCategory(id: number): Promise<void>;
  
  // Menu Item methods
  getMenuItems(): Promise<MenuItem[]>;
  getMenuItem(id: number): Promise<MenuItem | undefined>;
  getMenuItemsByCategory(categorySlug: string): Promise<MenuItem[]>;
  getBestsellers(): Promise<MenuItem[]>;
  createMenuItem(menuItem: InsertMenuItem): Promise<MenuItem>;
  updateMenuItem(id: number, menuItem: Partial<MenuItem>): Promise<MenuItem>;
  deleteMenuItem(id: number): Promise<void>;
  
  // Order methods
  getOrders(): Promise<Order[]>;
  getOrder(id: number): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: number, status: OrderStatus): Promise<Order>;
  
  // Telegram Bot Integration
  saveTelegramConfig(config: InsertTelegramConfig): Promise<TelegramConfig>;
  getTelegramConfig(): Promise<TelegramConfig | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categoriesStore: Map<number, Category>;
  private menuItemsStore: Map<number, MenuItem>;
  private ordersStore: Map<number, Order>;
  private telegramConfigStore: Map<number, TelegramConfig>;
  private userIdCounter: number;
  private categoryIdCounter: number;
  private menuItemIdCounter: number;
  private orderIdCounter: number;
  private telegramConfigIdCounter: number;

  constructor() {
    this.users = new Map();
    this.categoriesStore = new Map();
    this.menuItemsStore = new Map();
    this.ordersStore = new Map();
    this.telegramConfigStore = new Map();
    this.userIdCounter = 1;
    this.categoryIdCounter = 1;
    this.menuItemIdCounter = 1;
    this.orderIdCounter = 1;
    this.telegramConfigIdCounter = 1;
    
    // Initialize with sample data
    this.initializeData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { 
      id,
      username: insertUser.username,
      password: insertUser.password,
      email: insertUser.email ?? null,
      role: insertUser.role ?? null,
      isActive: true
    };
    this.users.set(id, user);
    return user;
  }
  
  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with id ${id} not found`);
    }
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async deleteUser(id: number): Promise<void> {
    if (!this.users.has(id)) {
      throw new Error(`User with id ${id} not found`);
    }
    this.users.delete(id);
  }
  
  // Category methods
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categoriesStore.values());
  }
  
  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categoriesStore.values()).find(
      (category) => category.slug === slug
    );
  }
  
  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.categoryIdCounter++;
    const category: Category = { ...insertCategory, id };
    this.categoriesStore.set(id, category);
    return category;
  }
  
  async updateCategory(id: number, categoryData: Partial<Category>): Promise<Category> {
    const category = this.categoriesStore.get(id);
    if (!category) {
      throw new Error(`Category with id ${id} not found`);
    }
    
    const updatedCategory = { ...category, ...categoryData };
    this.categoriesStore.set(id, updatedCategory);
    return updatedCategory;
  }
  
  async deleteCategory(id: number): Promise<void> {
    if (!this.categoriesStore.has(id)) {
      throw new Error(`Category with id ${id} not found`);
    }
    this.categoriesStore.delete(id);
  }
  
  // Menu Item methods
  async getMenuItems(): Promise<MenuItem[]> {
    return Array.from(this.menuItemsStore.values());
  }
  
  async getMenuItemsByCategory(categorySlug: string): Promise<MenuItem[]> {
    const category = await this.getCategoryBySlug(categorySlug);
    if (!category) return [];
    
    return Array.from(this.menuItemsStore.values()).filter(
      (item) => item.categoryId === category.id
    );
  }
  
  async getBestsellers(): Promise<MenuItem[]> {
    return Array.from(this.menuItemsStore.values()).filter(
      (item) => item.isBestseller
    );
  }
  
  async getMenuItem(id: number): Promise<MenuItem | undefined> {
    return this.menuItemsStore.get(id);
  }
  
  async createMenuItem(insertMenuItem: InsertMenuItem): Promise<MenuItem> {
    const id = this.menuItemIdCounter++;
    // Create a properly typed MenuItem object
    const menuItem: MenuItem = {
      id,
      categoryId: insertMenuItem.categoryId,
      titleUz: insertMenuItem.titleUz,
      titleRu: insertMenuItem.titleRu,
      titleEn: insertMenuItem.titleEn,
      descriptionUz: insertMenuItem.descriptionUz,
      descriptionRu: insertMenuItem.descriptionRu,
      descriptionEn: insertMenuItem.descriptionEn,
      price: insertMenuItem.price,
      image: insertMenuItem.image,
      type: insertMenuItem.type || "food",
      isBestseller: insertMenuItem.isBestseller === undefined ? false : insertMenuItem.isBestseller,
      discountPercentage: insertMenuItem.discountPercentage === undefined ? 0 : insertMenuItem.discountPercentage,
      rating: insertMenuItem.rating === undefined ? 5.0 : insertMenuItem.rating,
      beverageSizes: insertMenuItem.beverageSizes || null
    };
    this.menuItemsStore.set(id, menuItem);
    return menuItem;
  }
  
  async updateMenuItem(id: number, menuItemData: Partial<MenuItem>): Promise<MenuItem> {
    const menuItem = this.menuItemsStore.get(id);
    if (!menuItem) {
      throw new Error(`Menu item with id ${id} not found`);
    }
    
    const updatedMenuItem = { ...menuItem, ...menuItemData };
    this.menuItemsStore.set(id, updatedMenuItem);
    return updatedMenuItem;
  }
  
  async deleteMenuItem(id: number): Promise<void> {
    if (!this.menuItemsStore.has(id)) {
      throw new Error(`Menu item with id ${id} not found`);
    }
    this.menuItemsStore.delete(id);
  }
  
  // Order methods
  async getOrders(): Promise<Order[]> {
    return Array.from(this.ordersStore.values());
  }
  
  async getOrder(id: number): Promise<Order | undefined> {
    return this.ordersStore.get(id);
  }
  
  async createOrder(orderData: InsertOrder): Promise<Order> {
    const id = this.orderIdCounter++;
    const now = new Date();
    const order: Order = {
      id,
      userId: orderData.userId || null,
      customerName: orderData.customerName || null,
      customerPhone: orderData.customerPhone,
      customerAddress: orderData.customerAddress || null,
      orderItems: orderData.orderItems,
      totalAmount: orderData.totalAmount,
      status: orderData.status || "pending",
      paymentMethod: orderData.paymentMethod,
      deliveryOption: orderData.deliveryOption,
      createdAt: now,
      updatedAt: now
    };
    this.ordersStore.set(id, order);
    return order;
  }
  
  async updateOrderStatus(id: number, status: OrderStatus): Promise<Order> {
    const order = this.ordersStore.get(id);
    if (!order) {
      throw new Error(`Order with id ${id} not found`);
    }
    
    const updatedOrder = { 
      ...order, 
      status,
      updatedAt: new Date()
    };
    this.ordersStore.set(id, updatedOrder);
    return updatedOrder;
  }
  
  // Telegram Bot Integration
  async saveTelegramConfig(config: InsertTelegramConfig): Promise<TelegramConfig> {
    let existingConfig = await this.getTelegramConfig();
    
    if (existingConfig) {
      // Update existing config
      const updatedConfig = { 
        ...existingConfig, 
        botToken: config.botToken,
        chatId: config.chatId,
        notifyOnNewOrder: config.notifyOnNewOrder ?? existingConfig.notifyOnNewOrder,
        notifyOnStatusChange: config.notifyOnStatusChange ?? existingConfig.notifyOnStatusChange,
        updatedAt: new Date()
      };
      this.telegramConfigStore.set(existingConfig.id, updatedConfig);
      return updatedConfig;
    } else {
      // Create new config
      const id = this.telegramConfigIdCounter++;
      const now = new Date();
      const newConfig: TelegramConfig = { 
        id,
        botToken: config.botToken,
        chatId: config.chatId,
        notifyOnNewOrder: config.notifyOnNewOrder ?? true,
        notifyOnStatusChange: config.notifyOnStatusChange ?? true,
        createdAt: now,
        updatedAt: now
      };
      this.telegramConfigStore.set(id, newConfig);
      return newConfig;
    }
  }
  
  async getTelegramConfig(): Promise<TelegramConfig | undefined> {
    // As we only have one telegram config, we return the first one
    const configs = Array.from(this.telegramConfigStore.values());
    return configs.length > 0 ? configs[0] : undefined;
  }
  
  // Initialize with sample data
  private async initializeData() {
    // Create categories
    const burgers = await this.createCategory({
      nameUz: "Burgerlar",
      nameRu: "Бургеры",
      nameEn: "Burgers",
      slug: "burgers"
    });
    
    const pizzas = await this.createCategory({
      nameUz: "Pizzalar",
      nameRu: "Пиццы",
      nameEn: "Pizzas",
      slug: "pizzas"
    });
    
    const wraps = await this.createCategory({
      nameUz: "Lavashlar",
      nameRu: "Лаваши",
      nameEn: "Wraps",
      slug: "wraps"
    });
    
    const sandwiches = await this.createCategory({
      nameUz: "Sendvichlar",
      nameRu: "Сэндвичи",
      nameEn: "Sandwiches",
      slug: "sandwiches"
    });
    
    const drinks = await this.createCategory({
      nameUz: "Ichimliklar",
      nameRu: "Напитки",
      nameEn: "Drinks",
      slug: "drinks"
    });
    
    const desserts = await this.createCategory({
      nameUz: "Shirinliklar",
      nameRu: "Десерты",
      nameEn: "Desserts",
      slug: "desserts"
    });
    
    // Create menu items
    
    // Burgers
    await this.createMenuItem({
      categoryId: burgers.id,
      titleUz: "Burger Deluxe",
      titleRu: "Бургер Делюкс",
      titleEn: "Burger Deluxe",
      descriptionUz: "Ikki qavatli go'shtli burger maxsus sous, pishloq va yangi sabzavotlar bilan",
      descriptionRu: "Двухэтажный мясной бургер со специальным соусом, сыром и свежими овощами",
      descriptionEn: "Double-decker beef burger with special sauce, cheese, and fresh vegetables",
      price: 45000,
      image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
      isBestseller: true,
      discountPercentage: 0,
      rating: 4.8,
      type: "food"
    });
    
    await this.createMenuItem({
      categoryId: burgers.id,
      titleUz: "Cheese Burger",
      titleRu: "Чизбургер",
      titleEn: "Cheese Burger",
      descriptionUz: "Go'shtli burger, pishloq, pomidor, piyoz va maxsus sous bilan",
      descriptionRu: "Мясной бургер с сыром, помидорами, луком и специальным соусом",
      descriptionEn: "Beef burger with cheese, tomatoes, onions, and special sauce",
      price: 38000,
      image: "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
      isBestseller: false,
      discountPercentage: 0,
      rating: 4.5,
      type: "food"
    });
    
    // Pizzas
    await this.createMenuItem({
      categoryId: pizzas.id,
      titleUz: "Pepperoni Pizza",
      titleRu: "Пицца Пепперони",
      titleEn: "Pepperoni Pizza",
      descriptionUz: "Klassik pepperoni va mozzarella pishloqli pizza",
      descriptionRu: "Классическая пицца с пепперони и сыром моцарелла",
      descriptionEn: "Classic pepperoni and mozzarella cheese pizza",
      price: 85000,
      image: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
      isBestseller: false,
      discountPercentage: 15,
      rating: 4.7,
      type: "food"
    });
    
    await this.createMenuItem({
      categoryId: pizzas.id,
      titleUz: "Margarita Pizza",
      titleRu: "Пицца Маргарита",
      titleEn: "Margarita Pizza",
      descriptionUz: "Pomidor sousi, mozzarella pishloqi, oregano",
      descriptionRu: "Томатный соус, сыр моцарелла, орегано",
      descriptionEn: "Tomato sauce, mozzarella cheese, oregano",
      price: 62000,
      image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
      isBestseller: false,
      discountPercentage: 0,
      rating: 4.6,
      type: "food"
    });
    
    // Wraps
    await this.createMenuItem({
      categoryId: wraps.id,
      titleUz: "Tovuqli Lavash",
      titleRu: "Лаваш с курицей",
      titleEn: "Chicken Wrap",
      descriptionUz: "Tovuq go'shti, sabzavotlar va maxsus achchiq sous bilan",
      descriptionRu: "С куриным мясом, овощами и специальным острым соусом",
      descriptionEn: "Chicken meat, vegetables, and special spicy sauce",
      price: 32000,
      image: "https://images.unsplash.com/photo-1619881590738-a111d176d906?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
      isBestseller: true,
      discountPercentage: 0,
      rating: 4.6,
      type: "food"
    });
    
    await this.createMenuItem({
      categoryId: wraps.id,
      titleUz: "Go'shtli Lavash",
      titleRu: "Лаваш с говядиной",
      titleEn: "Beef Wrap",
      descriptionUz: "Mol go'shti, chips, bodring, pomidor, sous",
      descriptionRu: "Говядина, чипсы, огурцы, помидоры, соус",
      descriptionEn: "Beef, chips, cucumber, tomato, sauce",
      price: 32000,
      image: "https://images.unsplash.com/photo-1678030142034-a31724639cc4?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
      isBestseller: false,
      discountPercentage: 0,
      rating: 4.5,
      type: "food"
    });
    
    // Sandwiches
    await this.createMenuItem({
      categoryId: sandwiches.id,
      titleUz: "Club Sandwich",
      titleRu: "Клаб Сэндвич",
      titleEn: "Club Sandwich",
      descriptionUz: "Tovuq go'shti, tuxum, pomidor, salat barglari",
      descriptionRu: "Куриное мясо, яйцо, помидоры, листья салата",
      descriptionEn: "Chicken meat, egg, tomato, lettuce leaves",
      price: 36000,
      image: "https://images.unsplash.com/photo-1528736235302-52922df5c122?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
      isBestseller: false,
      discountPercentage: 0,
      rating: 4.4,
      type: "food"
    });
    
    // Drinks
    await this.createMenuItem({
      categoryId: drinks.id,
      titleUz: "Coca-Cola",
      titleRu: "Кока-Кола",
      titleEn: "Coca-Cola",
      descriptionUz: "Klassik gazlangan ichimlik",
      descriptionRu: "Классический газированный напиток",
      descriptionEn: "Classic carbonated drink",
      price: 12000,
      image: "https://images.unsplash.com/photo-1567103472667-6898f3a79cf2?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
      isBestseller: false,
      discountPercentage: 0,
      rating: 4.8,
      type: "beverage",
      beverageSizes: JSON.stringify({
        small: { volume: "0.5L", price: 12000 },
        medium: { volume: "1L", price: 18000 },
        large: { volume: "1.5L", price: 22000 }
      })
    });
    
    await this.createMenuItem({
      categoryId: drinks.id,
      titleUz: "Singo Meva Sharbati",
      titleRu: "Фруктовый Сок Синго",
      titleEn: "Singo Fruit Juice",
      descriptionUz: "Yangi siqilgan tabiiy meva sharbati, vitaminlarga boy",
      descriptionRu: "Свежевыжатый натуральный фруктовый сок, богатый витаминами",
      descriptionEn: "Freshly squeezed natural fruit juice, rich in vitamins",
      price: 15000,
      image: "https://images.unsplash.com/photo-1600271886742-f049cd451bba?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
      isBestseller: true,
      discountPercentage: 5,
      rating: 4.9,
      type: "beverage",
      beverageSizes: JSON.stringify({
        small: { volume: "0.3L", price: 15000 },
        medium: { volume: "0.5L", price: 20000 },
        large: { volume: "0.7L", price: 25000 }
      })
    });
    
    // Desserts
    await this.createMenuItem({
      categoryId: desserts.id,
      titleUz: "Chocolate Brownie",
      titleRu: "Шоколадный Брауни",
      titleEn: "Chocolate Brownie",
      descriptionUz: "Shokoladli brauni vanilli muzqaymoq bilan",
      descriptionRu: "Шоколадный брауни с ванильным мороженым",
      descriptionEn: "Chocolate brownie with vanilla ice cream",
      price: 28000,
      image: "https://images.unsplash.com/photo-1559715745-e1b33a271c8f?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
      isBestseller: false,
      discountPercentage: 0,
      rating: 4.9,
      type: "food"
    });
    
    // Wings
    await this.createMenuItem({
      categoryId: burgers.id,
      titleUz: "Tovuq Qanotlari",
      titleRu: "Куриные Крылышки",
      titleEn: "Chicken Wings",
      descriptionUz: "BBQ yoki achchiq sousli tovuq qanotlari porsiyasi",
      descriptionRu: "Порция куриных крылышек в соусе BBQ или остром",
      descriptionEn: "Portion of chicken wings with BBQ or spicy sauce",
      price: 48000,
      image: "https://images.unsplash.com/photo-1624153064067-566cae0ce184?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
      isBestseller: true,
      discountPercentage: 0,
      rating: 4.9,
      type: "food"
    });
  }
}

export const storage = new MemStorage();
