# Singo Fast Food - Installation Guide

## System Requirements

- Node.js 18.x or higher
- npm 8.x or higher

## Installation Steps

1. **Extract the archive**
   ```
   unzip singo_fast_food_app.zip
   cd singo_fast_food_app
   ```

2. **Install dependencies**
   ```
   npm install
   ```

3. **Start the application**
   ```
   npm run dev
   ```

4. **Access the application**
   - Open your browser and navigate to: http://localhost:5000
   - The admin panel is accessible at: http://localhost:5000/admin/login

## Default Credentials

- **Admin Panel:**
  - Username: admin
  - Password: admin

## Configuration (Optional)

- The application uses in-memory storage by default
- Change language settings using the language selector in the header
- Switch between light and dark mode using the theme toggle

## Troubleshooting

If you encounter any issues during installation or running the application:

1. Make sure you have the correct Node.js version installed
2. Try deleting the `node_modules` folder and running `npm install` again
3. Check if the port 5000 is already in use by another application

## Support

For any technical issues or questions, please contact support at:
- Email: support@singofastfood.uz
- Phone: +998 77 344 77 03